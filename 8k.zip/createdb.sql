-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Gegenereerd op: 04 mrt 2026 om 13:51
-- Serverversie: 10.11.6-MariaDB
-- PHP-versie: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prd-avg-register-voedselbankalmere`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `data_breaches`
--

CREATE TABLE `data_breaches` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `breach_date` date NOT NULL,
  `discovery_date` date NOT NULL,
  `breach_type` enum('confidentiality','integrity','availability','mixed') NOT NULL,
  `personal_data_affected` text NOT NULL,
  `affected_data_subjects` int(11) DEFAULT NULL,
  `causes` text NOT NULL,
  `measures_taken` text NOT NULL,
  `notified_authority` enum('yes','no','in_progress') DEFAULT 'no',
  `notification_date` date DEFAULT NULL,
  `notified_affected_persons` enum('yes','no','in_progress') DEFAULT 'no',
  `risk_level` enum('low','medium','high') NOT NULL,
  `status` enum('open','investigating','contained','resolved','closed') DEFAULT 'open',
  `reported_by` int(11) NOT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `dpia_registrations`
--

CREATE TABLE `dpia_registrations` (
  `id` int(11) NOT NULL,
  `record_id` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `necessity_proportionality` text DEFAULT NULL,
  `mitigation_measures` text DEFAULT NULL,
  `residual_risk` text DEFAULT NULL,
  `overall_risk_level` enum('low','medium','high') DEFAULT 'medium',
  `status` enum('draft','in_progress','under_review','approved','rejected','implemented') NOT NULL DEFAULT 'draft',
  `registered_by` int(11) NOT NULL,
  `registered_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `notes` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT 'DPIA Assessment',
  `review_date` date DEFAULT NULL,
  `processing_activity_description` text DEFAULT NULL,
  `risk_origin` enum('new_technology','large_scale','sensitive_data','systematic_monitoring','combination_datasets','vulnerable_groups','other') DEFAULT 'other',
  `necessity_test` text DEFAULT NULL,
  `proportionality_test` text DEFAULT NULL,
  `data_subjects_affected` int(11) DEFAULT 0,
  `data_categories` text DEFAULT NULL,
  `compliance_checklist` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`compliance_checklist`)),
  `risk_assessment_matrix` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`risk_assessment_matrix`)),
  `consultation_conducted` enum('yes','no','planned') DEFAULT 'no',
  `consultation_details` text DEFAULT NULL,
  `recommendations` text DEFAULT NULL,
  `management_approval` enum('pending','approved','rejected','revised') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approval_date` date DEFAULT NULL,
  `necessity` text DEFAULT NULL,
  `proportionality` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `dpia_registrations`
--


-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `gdpr_register`
--

CREATE TABLE `gdpr_register` (
  `id` int(11) NOT NULL,
  `has_processing_agreement_with_third_party` enum('Yes','No') DEFAULT 'No',
  `we_are_processor` enum('Yes','No') DEFAULT 'No',
  `processing_activity` varchar(500) NOT NULL,
  `name_data_controller` varchar(255) DEFAULT NULL,
  `contact_data_controller` varchar(255) DEFAULT NULL,
  `name_joint_data_controller` varchar(255) DEFAULT NULL,
  `contact_joint_data_controller` varchar(255) DEFAULT NULL,
  `name_representative` varchar(255) DEFAULT NULL,
  `contact_representative` varchar(255) DEFAULT NULL,
  `name_dpo` varchar(255) DEFAULT NULL,
  `contact_dpo` varchar(255) DEFAULT NULL,
  `purpose_of_processing` text NOT NULL,
  `legal_basis` varchar(300) NOT NULL,
  `categories_personal_data` text NOT NULL,
  `categories_data_subjects` varchar(300) NOT NULL,
  `categories_recipients` varchar(300) NOT NULL,
  `retention_periods` varchar(200) NOT NULL,
  `risk_level` enum('low','medium','high') NOT NULL,
  `technical_measures` text NOT NULL,
  `organizational_measures` text NOT NULL,
  `dpia_required` enum('yes','no') NOT NULL,
  `is_international_data_transfers` enum('yes','no','unknown') DEFAULT 'unknown',
  `to_country` enum('none','EU_EEA_Switzerland','UK','Argentina','Canada','Israel','Japan','New_Zealand','Republic_of_Korea','Uruguay','USA','Australia','Brazil','India','Mexico','Singapore','South_Africa','Other_third_country','Multiple_countries') DEFAULT 'none',
  `safeguards` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `review_due_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `department` enum('administration','distribution','volunteers','donations','marketing','other') DEFAULT 'other',
  `status` enum('active','inactive','archived','review_needed') DEFAULT 'active',
  `legitimate_interest_description` text DEFAULT NULL,
  `dpia_status` enum('open','in_progress','completed','not_required') DEFAULT 'not_required'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `gdpr_register`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `implementation_notes`
--

CREATE TABLE `implementation_notes` (
  `id` int(11) NOT NULL,
  `measure_id` int(11) NOT NULL,
  `note_text` text NOT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `security_measures`
--

CREATE TABLE `security_measures` (
  `id` int(11) NOT NULL,
  `gdpr_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `system_changes`
--

CREATE TABLE `system_changes` (
  `id` int(11) NOT NULL,
  `table_name` varchar(100) NOT NULL,
  `record_id` int(11) NOT NULL,
  `action` enum('INSERT','UPDATE','DELETE','VIEW','EXPORT','LOGIN','LOGOUT','PRINT') NOT NULL,
  `old_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_data`)),
  `new_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_data`)),
  `changed_fields` text DEFAULT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `changed_by` int(11) NOT NULL,
  `user_ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `system_changes`
--


-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `system_users`
--

CREATE TABLE `system_users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `role` enum('admin','editor','viewer') DEFAULT 'viewer',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `failed_login_attempts` int(11) DEFAULT 0,
  `account_locked_until` datetime DEFAULT NULL,
  `two_factor_secret` varchar(255) DEFAULT NULL,
  `two_factor_enabled` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `system_users`
--

INSERT INTO `system_users` (`id`, `username`, `password`, `email`, `full_name`, `role`, `is_active`, `last_login`, `created_at`, `updated_at`, `failed_login_attempts`, `account_locked_until`, `two_factor_secret`, `two_factor_enabled`) VALUES
(100000006, 'admin', '$2y$10$ifoYj1/m3mHWf5j27vIO2.ED5eEPCkQJ/aRV776aSHWDkrxYua./C', 'admin@foodbank-almere.nl', 'System Administrator', 'admin', 1, '2026-03-04 13:50:25', '2026-02-18 10:09:50', '2026-03-04 12:50:25', 0, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `third_parties`
--

CREATE TABLE `third_parties` (
  `id` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `service_provided` text NOT NULL,
  `processing_agreement_signed` enum('yes','no','in_progress') DEFAULT 'no',
  `agreement_date` date DEFAULT NULL,
  `agreement_expiry_date` date DEFAULT NULL,
  `compliance_status` enum('compliant','non_compliant','review_needed') DEFAULT 'review_needed',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `third_parties`
--


--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `data_breaches`
--
ALTER TABLE `data_breaches`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `dpia_registrations`
--
ALTER TABLE `dpia_registrations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_record_dpia` (`record_id`),
  ADD KEY `registered_by` (`registered_by`);

--
-- Indexen voor tabel `gdpr_register`
--
ALTER TABLE `gdpr_register`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_risk_level` (`risk_level`),
  ADD KEY `idx_dpia_required` (`dpia_required`),
  ADD KEY `idx_international_transfers` (`is_international_data_transfers`);

--
-- Indexen voor tabel `implementation_notes`
--
ALTER TABLE `implementation_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `measure_id` (`measure_id`);

--
-- Indexen voor tabel `security_measures`
--
ALTER TABLE `security_measures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gdpr_id` (`gdpr_id`);

--
-- Indexen voor tabel `system_changes`
--
ALTER TABLE `system_changes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `changed_by` (`changed_by`);

--
-- Indexen voor tabel `system_users`
--
ALTER TABLE `system_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexen voor tabel `third_parties`
--
ALTER TABLE `third_parties`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `data_breaches`
--
ALTER TABLE `data_breaches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT voor een tabel `dpia_registrations`
--
ALTER TABLE `dpia_registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=300000009;

--
-- AUTO_INCREMENT voor een tabel `gdpr_register`
--
ALTER TABLE `gdpr_register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=200000036;

--
-- AUTO_INCREMENT voor een tabel `implementation_notes`
--
ALTER TABLE `implementation_notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `security_measures`
--
ALTER TABLE `security_measures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `system_changes`
--
ALTER TABLE `system_changes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=238;

--
-- AUTO_INCREMENT voor een tabel `system_users`
--
ALTER TABLE `system_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100000007;

--
-- AUTO_INCREMENT voor een tabel `third_parties`
--
ALTER TABLE `third_parties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `dpia_registrations`
--
ALTER TABLE `dpia_registrations`
  ADD CONSTRAINT `dpia_registrations_ibfk_1` FOREIGN KEY (`record_id`) REFERENCES `gdpr_register` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `dpia_registrations_ibfk_2` FOREIGN KEY (`registered_by`) REFERENCES `system_users` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `implementation_notes`
--
ALTER TABLE `implementation_notes`
  ADD CONSTRAINT `implementation_notes_ibfk_1` FOREIGN KEY (`measure_id`) REFERENCES `security_measures` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `security_measures`
--
ALTER TABLE `security_measures`
  ADD CONSTRAINT `security_measures_ibfk_1` FOREIGN KEY (`gdpr_id`) REFERENCES `gdpr_register` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `system_changes`
--
ALTER TABLE `system_changes`
  ADD CONSTRAINT `system_changes_ibfk_1` FOREIGN KEY (`changed_by`) REFERENCES `system_users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
