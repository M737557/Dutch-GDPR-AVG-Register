<?php
/**
 * Food Bank Almere - Quick Activities Summary
 * Simple summary page for quick overview
 */

require_once __DIR__ . '/9-5.php';

if (!$is_logged_in || !has_permission('view_activities')) {
    die('Access denied');
}

// Get quick statistics
function get_quick_statistics() {
    $conn = create_db_connection();
    $stats = [];
    
    // Basic counts
    $result = $conn->query("SELECT COUNT(*) as total FROM gdpr_register");
    $stats['total'] = $result->fetch_assoc()['total'];
    
    // By department
    $result = $conn->query("
        SELECT department, COUNT(*) as count 
        FROM gdpr_register 
        GROUP BY department 
        ORDER BY COUNT(*) DESC
    ");
    $stats['by_department'] = [];
    while ($row = $result->fetch_assoc()) {
        $stats['by_department'][] = $row;
    }
    
    // By risk level
    $result = $conn->query("
        SELECT risk_level, COUNT(*) as count 
        FROM gdpr_register 
        GROUP BY risk_level 
        ORDER BY FIELD(risk_level, 'high', 'medium', 'low')
    ");
    $stats['by_risk'] = [];
    while ($row = $result->fetch_assoc()) {
        $stats['by_risk'][] = $row;
    }
    
    // Recent activities
    $result = $conn->query("
        SELECT id, processing_activity, department, risk_level, updated_at 
        FROM gdpr_register 
        ORDER BY updated_at DESC 
        LIMIT 10
    ");
    $stats['recent'] = [];
    while ($row = $result->fetch_assoc()) {
        $stats['recent'][] = $row;
    }
    
    return $stats;
}

$stats = get_quick_statistics();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quick Activities Summary - Food Bank Almere</title>
    <link href="bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 20px; background-color: #f8f9fa; }
        .card { margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .stat-card { text-align: center; padding: 20px; }
        .stat-number { font-size: 2.5rem; font-weight: bold; }
        .stat-label { color: #6c757d; text-transform: uppercase; font-size: 0.9rem; }
        .badge-risk { padding: 5px 10px; border-radius: 20px; font-weight: bold; }
        .badge-high { background-color: #dc3545; color: white; }
        .badge-medium { background-color: #ffc107; color: #000; }
        .badge-low { background-color: #28a745; color: white; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row mb-4">
            <div class="col">
                <h1 class="display-5">Processing Activities Summary</h1>
                <p class="lead">Quick overview of all processing activities</p>
                <p class="text-muted">Generated: <?php echo date('d-m-Y H:i'); ?></p>
            </div>
        </div>
        
        <!-- Summary Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body stat-card">
                        <div class="stat-number"><?php echo $stats['total']; ?></div>
                        <div class="stat-label">Total Activities</div>
                    </div>
                </div>
            </div>
            
            <?php 
            $risk_counts = [
                'high' => 0,
                'medium' => 0,
                'low' => 0
            ];
            foreach ($stats['by_risk'] as $risk) {
                $risk_counts[$risk['risk_level']] = $risk['count'];
            }
            ?>
            
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body stat-card">
                        <div class="stat-number text-danger"><?php echo $risk_counts['high']; ?></div>
                        <div class="stat-label">High Risk Activities</div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body stat-card">
                        <div class="stat-number text-warning"><?php echo $risk_counts['medium']; ?></div>
                        <div class="stat-label">Medium Risk Activities</div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body stat-card">
                        <div class="stat-number text-success"><?php echo $risk_counts['low']; ?></div>
                        <div class="stat-label">Low Risk Activities</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Department Breakdown -->
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">By Department</h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Department</th>
                                    <th>Count</th>
                                    <th>Percentage</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($stats['by_department'] as $dept): 
                                    $percentage = $stats['total'] > 0 ? round(($dept['count'] / $stats['total']) * 100, 1) : 0;
                                    $dept_name = $dept['department'];
                                ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($dept_name); ?></td>
                                    <td><?php echo $dept['count']; ?></td>
                                    <td>
                                        <div class="progress" style="height: 20px;">
                                            <div class="progress-bar" role="progressbar" style="width: <?php echo $percentage; ?>%">
                                                <?php echo $percentage; ?>%
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Recent Activities -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Recently Updated Activities</h5>
                    </div>
                    <div class="card-body">
                        <div class="list-group">
                            <?php foreach ($stats['recent'] as $activity): 
                                $badge_class = 'badge-' . ($activity['risk_level'] == 'high' ? 'danger' : ($activity['risk_level'] == 'medium' ? 'warning' : 'success'));
                            ?>
                            <a href="?action=edit_activity&id=<?php echo $activity['id']; ?>" class="list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1"><?php echo htmlspecialchars($activity['processing_activity']); ?></h6>
                                    <span class="badge <?php echo $badge_class; ?>">
                                        <?php echo strtoupper($activity['risk_level']); ?>
                                    </span>
                                </div>
                                <small class="text-muted">
                                    <?php echo htmlspecialchars($activity['department']); ?> | 
                                    Updated: <?php echo format_date($activity['updated_at'], 'd-m-Y H:i'); ?>
                                </small>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="row mt-4">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Quick Actions</h5>
                        <div class="btn-group" role="group">
                            <a href="?action=view_activities" class="btn btn-primary">
                                <i class="bi bi-list-ul"></i> View All Activities
                            </a>
                            <a href="?action=add_activity" class="btn btn-success">
                                <i class="bi bi-plus-circle"></i> Add New Activity
                            </a>
                            <a href="generate_activities_summary.php?type=excel" class="btn btn-info">
                                <i class="bi bi-download"></i> Export to Excel
                            </a>
                            <a href="generate_activities_summary.php?type=print" target="_blank" class="btn btn-secondary">
                                <i class="bi bi-printer"></i> Print Summary
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Risk Distribution Chart -->
        <div class="row mt-4">
            <div class="col">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Risk Level Distribution</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-8">
                                <!-- Simple bar chart using Bootstrap -->
                                <div class="progress" style="height: 40px;">
                                    <?php 
                                    $total = $stats['total'];
                                    if ($total > 0) {
                                        $high_percent = ($risk_counts['high'] / $total) * 100;
                                        $medium_percent = ($risk_counts['medium'] / $total) * 100;
                                        $low_percent = ($risk_counts['low'] / $total) * 100;
                                    } else {
                                        $high_percent = $medium_percent = $low_percent = 0;
                                    }
                                    ?>
                                    <div class="progress-bar bg-danger" style="width: <?php echo $high_percent; ?>%" 
                                         title="High Risk: <?php echo $risk_counts['high']; ?> activities">
                                        <?php if ($high_percent > 10): ?>
                                            <?php echo round($high_percent, 1); ?>%
                                        <?php endif; ?>
                                    </div>
                                    <div class="progress-bar bg-warning" style="width: <?php echo $medium_percent; ?>%" 
                                         title="Medium Risk: <?php echo $risk_counts['medium']; ?> activities">
                                        <?php if ($medium_percent > 10): ?>
                                            <?php echo round($medium_percent, 1); ?>%
                                        <?php endif; ?>
                                    </div>
                                    <div class="progress-bar bg-success" style="width: <?php echo $low_percent; ?>%" 
                                         title="Low Risk: <?php echo $risk_counts['low']; ?> activities">
                                        <?php if ($low_percent > 10): ?>
                                            <?php echo round($low_percent, 1); ?>%
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <ul class="list-unstyled">
                                    <li><span class="badge bg-danger me-2"></span> High Risk: <?php echo $risk_counts['high']; ?></li>
                                    <li><span class="badge bg-warning me-2"></span> Medium Risk: <?php echo $risk_counts['medium']; ?></li>
                                    <li><span class="badge bg-success me-2"></span> Low Risk: <?php echo $risk_counts['low']; ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="row mt-4">
            <div class="col">
                <div class="text-center text-muted">
                    <hr>
                    <p>Food Bank Almere GDPR System | Generated on <?php echo date('d-m-Y H:i'); ?></p>
                    <p><a href="?action=dashboard" class="text-decoration-none">← Back to Dashboard</a></p>
                </div>
            </div>
        </div>
    </div>
    
    <script src="bootstrap.bundle.min.js"></script>
</body>
</html>