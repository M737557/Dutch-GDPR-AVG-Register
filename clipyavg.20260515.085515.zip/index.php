<?php
// ============================================
// GDPR & DPIA PDF Generator - Toon ALLE details
// ============================================

// Configuration
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Use relative path instead of absolute Windows path
$data_directory = __DIR__ . '/dutch/';

// Check if directory exists
if (!is_dir($data_directory)) {
    die('Data directory not found: ' . htmlspecialchars($data_directory));
}

// GENEREER DIRECT HET RAPPORT ZONDER VRAAG
try {
    generateGDPRDPIAPDF($data_directory);
} catch (Exception $e) {
    die('Fout bij genereren rapport: ' . $e->getMessage());
}

// Functie om PDF rapport te genereren
function generateGDPRDPIAPDF($data_directory) {
    // Haal alle data op
    $all_entries = [];
    $files = getAllDataFiles($data_directory);
    
    foreach ($files as $file) {
        $entries = parseFileContent($file);
        $all_entries = array_merge($all_entries, $entries);
    }
    
    // Genereer HTML rapport
    $html = generateHTMLReport($all_entries);
    
    // Stuur HTML naar browser met print styling
    header('Content-Type: text/html; charset=utf-8');
    echo $html;
    exit;
}

// Helper functies
function getAllDataFiles($directory) {
    $files = [];
    if (is_dir($directory)) {
        $all_files = scandir($directory);
        foreach ($all_files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'txt' && $file !== '.' && $file !== '..') {
                $files[] = $directory . $file;
            }
        }
    }
    return $files;
}

function parseFileContent($filepath) {
    $entries = [];
    
    // Validatie van bestandspad
    if (!file_exists($filepath)) {
        throw new Exception("Bestand niet gevonden: " . basename($filepath));
    }
    
    // Controleer bestandsgrootte (max 10MB)
    if (filesize($filepath) > 10485760) {
        throw new Exception("Bestand te groot: " . basename($filepath));
    }
    
    // Lees inhoud
    $content = @file_get_contents($filepath);
    if ($content === false) {
        throw new Exception("Kon bestand niet lezen: " . basename($filepath));
    }
    
    $lines = explode("\n", $content);
    
    foreach ($lines as $line) {
        $trimmed = trim($line);
        if (strpos($trimmed, '--') === 0 || $trimmed === '' || strpos($trimmed, 'INSERT INTO') !== false) {
            continue;
        }
        
        if (strpos($trimmed, '(') === 0) {
            $data = parseDataRow($trimmed);
            if ($data && isset($data[0])) {
                $detected_type = detectFileTypeFromRow($data);
                
                $entry = [
                    'id' => $data[0] ?? '',
                    'type' => $detected_type,
                    'file' => basename($filepath),
                    'raw_data' => $data,
                    'field_count' => count($data),
                    'all_fields' => $data
                ];
                
                // COLUMN NAMES voor GDPR (33 velden)
                $gdpr_columns = [
                    'id', 'has_processing_agreement_with_third_party', 'we_are_processor', 'processing_activity', 'name_data_controller',
                    'contact_data_controller', 'name_joint_data_controller', 'contact_joint_data_controller', 'name_representative',
                    'contact_representative', 'name_dpo', 'contact_dpo', 'purpose_of_processing', 'legal_basis',
                    'categories_personal_data', 'categories_data_subjects', 'categories_recipients', 'retention_periods',
                    'risk_level', 'technical_measures', 'organizational_measures', 'dpia_required', 'is_international_data_transfers',
                    'to_country', 'safeguards', 'created_at', 'updated_at', 'review_due_date', 'created_by', 'updated_by',
                    'department', 'status', 'legitimate_interest_description', 'dpia_status'
                ];
                
                // COLUMN NAMES voor DPIA (28 velden)
                $dpia_columns = [
                    'id', 'record_id', 'description', 'necessity_proportionality', 'mitigation_measures', 'residual_risk',
                    'overall_risk_level', 'status', 'registered_by', 'registered_at', 'updated_at', 'notes', 'title',
                    'review_date', 'processing_activity_description', 'risk_origin', 'necessity_test', 'proportionality_test',
                    'data_subjects_affected', 'data_categories', 'compliance_checklist', 'risk_assessment_matrix',
                    'consultation_conducted', 'consultation_details', 'recommendations', 'management_approval',
                    'approved_by', 'approval_date'
                ];
                
                // Voeg alle velden toe met kolomnamen
                if ($detected_type === 'gdpr') {
                    $entry['columns'] = $gdpr_columns;
                    // Voeg alle velden toe
                    for ($i = 0; $i < min(count($data), count($gdpr_columns)); $i++) {
                        $column_name = $gdpr_columns[$i];
                        $entry[$column_name] = $data[$i] ?? '';
                    }
                } elseif ($detected_type === 'dpia') {
                    $entry['columns'] = $dpia_columns;
                    // Voeg alle velden toe
                    for ($i = 0; $i < min(count($data), count($dpia_columns)); $i++) {
                        $column_name = $dpia_columns[$i];
                        $entry[$column_name] = $data[$i] ?? '';
                    }
                } else {
                    $entry['columns'] = [];
                }
                
                $entries[] = $entry;
            }
        }
    }
    
    return $entries;
}

function parseDataRow($line) {
    $line = trim($line, ");\n\r\t");
    $line = trim($line, "),");
    
    $values = [];
    $current = '';
    $in_quotes = false;
    $escaped = false;
    
    for ($i = 0; $i < strlen($line); $i++) {
        $char = $line[$i];
        
        if ($char === '\\') {
            $escaped = !$escaped;
            $current .= $char;
        } elseif ($char === "'" && !$escaped) {
            $in_quotes = !$in_quotes;
            $current .= $char;
        } elseif ($char === ',' && !$in_quotes && !$escaped) {
            $values[] = trim($current, "'");
            $current = '';
        } else {
            $current .= $char;
            $escaped = false;
        }
    }
    
    if ($current !== '') {
        $values[] = trim($current, "'");
    }
    
    return $values;
}

function detectFileTypeFromRow($data) {
    if (count($data) >= 33) {
        return 'gdpr';
    } elseif (count($data) >= 28) {
        return 'dpia';
    }
    return 'unknown';
}

// Genereer HTML rapport met ALLE details
function generateHTMLReport($entries) {
    // Tel statistieken
    $gdpr_count = count(array_filter($entries, function($e) { return $e['type'] === 'gdpr'; }));
    $dpia_count = count(array_filter($entries, function($e) { return $e['type'] === 'dpia'; }));
    
    $html = '<!DOCTYPE html>
    <html lang="nl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
        <title>GDPR & DPIA Register - Compleet Overzicht</title>
        <style>
            /* Print styles */
            @media print {
                @page {
                    size: A4;
                    margin: 1.5cm;
                }
                body {
                    font-family: Arial, sans-serif;
                    font-size: 10pt;
                    line-height: 1.3;
                    color: #000;
                }
                .page-break {
                    page-break-after: always;
                }
                .no-print {
                    display: none;
                }
                h1, h2, h3, h4 {
                    page-break-after: avoid;
                }
                .entry {
                    page-break-inside: avoid;
                }
                .details-table {
                    font-size: 9pt;
                }
                .print-hide {
                    display: none !important;
                }
            }
            
            /* Mobile First Styles */
            * {
                box-sizing: border-box;
                margin: 0;
                padding: 0;
            }
            
            body {
                font-family: Arial, sans-serif;
                line-height: 1.4;
                color: #333;
                padding: 0;
                margin: 0;
                background: #f5f5f5;
                font-size: 14px;
            }
            
            .container {
                padding: 10px;
                background: white;
                min-height: 100vh;
            }
            
            .header {
                text-align: center;
                margin-bottom: 20px;
                padding-bottom: 15px;
                border-bottom: 2px solid #2c3e50;
            }
            
            h1 {
                font-size: 20px;
                margin: 0 0 8px 0;
                color: #2c3e50;
                word-wrap: break-word;
            }
            
            .subtitle {
                font-size: 13px;
                color: #666;
                margin-bottom: 10px;
            }
            
            .info-box {
                background: #e8f4fc;
                border: 1px solid #b6d4fe;
                border-radius: 5px;
                padding: 10px;
                margin-bottom: 15px;
                font-size: 13px;
            }
            
            .section {
                margin-bottom: 20px;
            }
            
            h2 {
                font-size: 18px;
                color: #34495e;
                border-bottom: 2px solid #3498db;
                padding-bottom: 5px;
                margin-top: 20px;
                margin-bottom: 15px;
            }
            
            h3 {
                font-size: 16px;
                color: #2c3e50;
                margin-top: 15px;
                margin-bottom: 10px;
                background: #f8f9fa;
                padding: 8px;
                border-left: 4px solid #3498db;
                word-wrap: break-word;
            }
            
            h4 {
                font-size: 14px;
                color: #495057;
                margin-top: 15px;
                margin-bottom: 10px;
            }
            
            .entry {
                border: 1px solid #ddd;
                border-radius: 5px;
                padding: 12px;
                margin-bottom: 15px;
                background: #fff;
                box-shadow: 0 1px 3px rgba(0,0,0,0.05);
                overflow: hidden;
            }
            
            .entry-header {
                background: linear-gradient(to right, #f8f9fa, #e9ecef);
                padding: 8px 12px;
                margin: -12px -12px 12px -12px;
                border-bottom: 1px solid #dee2e6;
                border-radius: 5px 5px 0 0;
                display: flex;
                flex-wrap: wrap;
                gap: 8px;
                align-items: center;
            }
            
            .entry-title {
                font-size: 14px;
                font-weight: bold;
                color: #2c3e50;
            }
            
            .entry-meta {
                font-size: 11px;
                color: #666;
                word-break: break-all;
            }
            
            .badge {
                display: inline-block;
                padding: 3px 6px;
                border-radius: 4px;
                font-size: 11px;
                font-weight: bold;
                margin-right: 5px;
                white-space: nowrap;
            }
            
            .badge-gdpr {
                background: #3498db;
                color: white;
            }
            
            .badge-dpia {
                background: #e74c3c;
                color: white;
            }
            
            .badge-high {
                background: #dc3545;
                color: white;
            }
            
            .badge-medium {
                background: #ffc107;
                color: #212529;
            }
            
            .badge-low {
                background: #28a745;
                color: white;
            }
            
            .badge-unknown {
                background: #6c757d;
                color: white;
            }
            
            .details-table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 12px;
                font-size: 12px;
                overflow-x: auto;
                display: block;
            }
            
            .details-table th {
                background: #f8f9fa;
                font-weight: bold;
                text-align: left;
                padding: 8px;
                border: 1px solid #dee2e6;
                vertical-align: top;
                word-break: break-word;
            }
            
            .details-table td {
                padding: 8px;
                border: 1px solid #dee2e6;
                vertical-align: top;
                background: white;
                word-break: break-word;
            }
            
            .details-table tr:nth-child(even) td {
                background: #f8f9fa;
            }
            
            .field-value {
                word-break: break-word;
                overflow-wrap: break-word;
                white-space: normal;
            }
            
            .empty-field {
                color: #999;
                font-style: italic;
            }
            
            .statistics {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
                gap: 10px;
                margin-bottom: 20px;
            }
            
            .stat-card {
                background: #f8f9fa;
                border: 1px solid #dee2e6;
                border-radius: 5px;
                padding: 12px;
                text-align: center;
                box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            }
            
            .stat-number {
                font-size: 18px;
                font-weight: bold;
                color: #2c3e50;
                display: block;
                margin-bottom: 5px;
            }
            
            .stat-label {
                font-size: 11px;
                color: #666;
            }
            
            .footer {
                text-align: center;
                margin-top: 30px;
                padding-top: 15px;
                border-top: 1px solid #ddd;
                font-size: 11px;
                color: #666;
            }
            
            .raw-data {
                background: #f8f9fa;
                border: 1px dashed #ccc;
                padding: 10px;
                margin-top: 15px;
                font-family: monospace;
                font-size: 11px;
                display: none;
                overflow-x: auto;
            }
            
            .raw-data.show {
                display: block;
            }
            
            .index-badge {
                background: #6c757d;
                color: white;
                padding: 2px 6px;
                border-radius: 3px;
                font-size: 10px;
                margin-right: 5px;
            }
            
            .all-fields-table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 12px;
                font-size: 11px;
                overflow-x: auto;
                display: block;
            }
            
            .all-fields-table th {
                background: #e9ecef;
                font-weight: bold;
                padding: 6px;
                border: 1px solid #dee2e6;
                text-align: left;
                word-break: break-word;
            }
            
            .all-fields-table td {
                padding: 6px;
                border: 1px solid #dee2e6;
                vertical-align: top;
                word-break: break-word;
            }
            
            .all-fields-table tr:nth-child(even) {
                background: #f8f9fa;
            }
            
            .column-index {
                width: 40px;
                text-align: center;
                background: #e9ecef;
                font-weight: bold;
            }
            
            .column-name {
                width: 120px;
                font-weight: bold;
                background: #f1f3f4;
            }
            
            .column-value {
                background: white;
                min-width: 100px;
            }
            
            .mobile-only {
                display: none;
            }
            
            /* Responsive Design */
            @media screen and (max-width: 768px) {
                body {
                    font-size: 12px;
                }
                
                .container {
                    padding: 8px;
                }
                
                h1 {
                    font-size: 18px;
                }
                
                h2 {
                    font-size: 16px;
                }
                
                h3 {
                    font-size: 14px;
                }
                
                .statistics {
                    grid-template-columns: repeat(2, 1fr);
                    gap: 8px;
                }
                
                .stat-card {
                    padding: 8px;
                }
                
                .stat-number {
                    font-size: 16px;
                }
                
                .details-table,
                .all-fields-table {
                    font-size: 10px;
                }
                
                .details-table th,
                .details-table td {
                    padding: 6px 4px;
                }
                
                .all-fields-table th,
                .all-fields-table td {
                    padding: 4px 2px;
                    font-size: 10px;
                }
                
                .entry-header {
                    flex-direction: column;
                    align-items: flex-start;
                    gap: 8px;
                }
                
                .badge {
                    font-size: 10px;
                    padding: 2px 4px;
                }
                
                .column-name {
                    width: 100px;
                }
                
                .mobile-only {
                    display: inline;
                }
                
                .desktop-only {
                    display: none;
                }
            }
            
            @media screen and (max-width: 480px) {
                .statistics {
                    grid-template-columns: 1fr;
                }
                
                .details-table {
                    display: block;
                }
                
                .details-table tr {
                    display: block;
                    margin-bottom: 10px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                }
                
                .details-table th,
                .details-table td {
                    display: block;
                    width: 100% !important;
                    border: none;
                    padding: 8px;
                }
                
                .details-table th {
                    background: #f0f0f0;
                    border-bottom: 1px solid #ddd;
                }
                
                .all-fields-table {
                    font-size: 9px;
                }
                
                .column-index {
                    width: 30px;
                }
                
                .column-name {
                    width: 80px;
                }
            }
            
            @media screen and (min-width: 1200px) {
                .container {
                    max-width: 210mm;
                    margin: 0 auto;
                    padding: 15px;
                }
            }
            
            /* Print optimization */
            .print-optimize {
                break-inside: avoid;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>GDPR & DPIA Register - Compleet Overzicht</h1>
                <div class="subtitle">Generatiedatum: ' . date('d-m-Y H:i:s') . ' | ' . count($entries) . ' entries gevonden</div>
            </div>
            
            <div class="statistics">
                <div class="stat-card">
                    <span class="stat-number">' . count($entries) . '</span>
                    <span class="stat-label">Totaal Entries</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number">' . $gdpr_count . '</span>
                    <span class="stat-label">GDPR Verwerkingen</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number">' . $dpia_count . '</span>
                    <span class="stat-label">DPIA Assessments</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number">' . count(array_filter($entries, function($e) { 
                        return $e['type'] === 'unknown'; 
                    })) . '</span>
                    <span class="stat-label">Onbekend Type</span>
                </div>
            </div>
            
            <div class="info-box print-hide">
                <strong>ℹ️ Informatie:</strong> Gebruik Ctrl+P (Windows) of Cmd+P (Mac) om te printen of als PDF op te slaan.
            </div>';
    
    // GDPR Sectie met ALLE details
    if ($gdpr_count > 0) {
        $html .= '<div class="section print-optimize">
            <h2>1. GDPR Verwerkingen (' . $gdpr_count . ')</h2>
            <div class="info-box">
                <strong>ℹ️ Informatie:</strong> Deze sectie toont alle ' . $gdpr_count . ' GDPR verwerkingen met alle velden per verwerking.
            </div>';
        
        $gdpr_entries = array_filter($entries, function($e) { return $e['type'] === 'gdpr'; });
        $gdpr_entries = array_values($gdpr_entries);
        
        foreach ($gdpr_entries as $index => $entry) {
            $risk_class = !empty($entry['risk_level']) ? strtolower($entry['risk_level']) : 'unknown';
            $risk_display = !empty($entry['risk_level']) ? $entry['risk_level'] : 'Onbekend';
            
            $html .= '<div class="entry print-optimize">
                <div class="entry-header">
                    <div>
                        <span class="badge badge-gdpr">GDPR</span>
                        <span class="badge badge-' . $risk_class . '">' . $risk_display . ' risico</span>
                        <span class="index-badge">#' . ($index + 1) . '</span>
                    </div>
                    <div class="entry-meta">
                        ID: ' . htmlspecialchars($entry['id']) . ' | Bestand: ' . htmlspecialchars($entry['file']) . '
                    </div>
                </div>
                
                <h3>' . htmlspecialchars($entry['processing_activity'] ?? 'Verwerking ' . $entry['id']) . '</h3>';
            
            // Belangrijke velden eerst in een compacte tabel
            $important_fields_gdpr = [
                'name_data_controller' => 'Verwerkingsverantwoordelijke',
                'purpose_of_processing' => 'Doel van de verwerking',
                'legal_basis' => 'Wettelijke grondslag',
                'categories_personal_data' => 'Categorieën persoonsgegevens',
                'categories_data_subjects' => 'Betrokken personen',
                'retention_periods' => 'Bewaartermijn',
                'risk_level' => 'Risiconiveau',
                'dpia_required' => 'DPIA vereist',
                'status' => 'Status',
                'department' => 'Afdeling',
                'review_due_date' => 'Herbeoordelingsdatum',
                'created_at' => 'Aangemaakt op',
                'updated_at' => 'Bijgewerkt op'
            ];
            
            $html .= '<table class="details-table">
                <tbody>';
            
            foreach ($important_fields_gdpr as $field => $label) {
                if (isset($entry[$field]) && $entry[$field] !== '') {
                    $html .= '<tr>
                        <th>' . $label . ':</th>
                        <td class="field-value">' . nl2br(htmlspecialchars($entry[$field])) . '</td>
                    </tr>';
                }
            }
            
            $html .= '</tbody>
                </table>';
            
            // Toon ALLE velden in een gedetailleerde tabel
            $html .= '<h4>Alle Velden (' . count($entry['all_fields']) . '):</h4>
                <table class="all-fields-table">
                    <thead>
                        <tr>
                            <th class="column-index">#</th>
                            <th class="column-name">Veldnaam</th>
                            <th class="column-value">Waarde</th>
                        </tr>
                    </thead>
                    <tbody>';
            
            for ($i = 0; $i < count($entry['all_fields']); $i++) {
                $value = $entry['all_fields'][$i] ?? '';
                $column_name = isset($entry['columns'][$i]) ? $entry['columns'][$i] : "veld_$i";
                
                $html .= '<tr>
                    <td class="column-index">' . $i . '</td>
                    <td class="column-name">' . htmlspecialchars($column_name) . '</td>
                    <td class="column-value">' . ($value !== '' ? nl2br(htmlspecialchars($value)) : '<span class="empty-field">(leeg)</span>') . '</td>
                </tr>';
            }
            
            $html .= '</tbody>
                </table>';
            
            $html .= '</div>';
            
            // Pagina break na elke 2 entries (voor print)
            if (($index + 1) % 2 === 0 && ($index + 1) < count($gdpr_entries)) {
                $html .= '<div class="page-break"></div>';
            }
        }
        
        $html .= '</div>';
    }
    
    // DPIA Sectie met ALLE details
    if ($dpia_count > 0) {
        $html .= '<div class="page-break"></div>
            <div class="section print-optimize">
                <h2>2. DPIA Assessments (' . $dpia_count . ')</h2>
                <div class="info-box">
                    <strong>ℹ️ Informatie:</strong> Deze sectie toont alle ' . $dpia_count . ' DPIA assessments met alle velden per assessment.
                </div>';
        
        $dpia_entries = array_filter($entries, function($e) { return $e['type'] === 'dpia'; });
        $dpia_entries = array_values($dpia_entries);
        
        foreach ($dpia_entries as $index => $entry) {
            $risk_class = !empty($entry['overall_risk_level']) ? strtolower($entry['overall_risk_level']) : 'unknown';
            $risk_display = !empty($entry['overall_risk_level']) ? $entry['overall_risk_level'] : 'Onbekend';
            
            $html .= '<div class="entry print-optimize">
                <div class="entry-header">
                    <div>
                        <span class="badge badge-dpia">DPIA</span>
                        <span class="badge badge-' . $risk_class . '">' . $risk_display . ' risico</span>
                        <span class="index-badge">#' . ($index + 1) . '</span>
                    </div>
                    <div class="entry-meta">
                        ID: ' . htmlspecialchars($entry['id']) . ' | Bestand: ' . htmlspecialchars($entry['file']) . '
                    </div>
                </div>
                
                <h3>' . htmlspecialchars($entry['title'] ?? 'DPIA ' . $entry['id']) . '</h3>';
            
            // Belangrijke velden eerst
            $important_fields_dpia = [
                'description' => 'Beschrijving',
                'processing_activity_description' => 'Verwerkingsactiviteit',
                'necessity_proportionality' => 'Noodzaak & evenredigheid',
                'mitigation_measures' => 'Mitigerende maatregelen',
                'residual_risk' => 'Resterend risico',
                'overall_risk_level' => 'Totaal risiconiveau',
                'status' => 'Status',
                'registered_at' => 'Geregistreerd op',
                'review_date' => 'Herbeoordelingsdatum',
                'data_subjects_affected' => 'Betrokken personen',
                'risk_origin' => 'Oorsprong risico',
                'consultation_conducted' => 'Consultatie uitgevoerd',
                'management_approval' => 'Goedkeuring management'
            ];
            
            $html .= '<table class="details-table">
                <tbody>';
            
            foreach ($important_fields_dpia as $field => $label) {
                if (isset($entry[$field]) && $entry[$field] !== '') {
                    $html .= '<tr>
                        <th>' . $label . ':</th>
                        <td class="field-value">' . nl2br(htmlspecialchars($entry[$field])) . '</td>
                    </tr>';
                }
            }
            
            $html .= '</tbody>
                </table>';
            
            // Toon ALLE velden in een gedetailleerde tabel
            $html .= '<h4>Alle Velden (' . count($entry['all_fields']) . '):</h4>
                <table class="all-fields-table">
                    <thead>
                        <tr>
                            <th class="column-index">#</th>
                            <th class="column-name">Veldnaam</th>
                            <th class="column-value">Waarde</th>
                        </tr>
                    </thead>
                    <tbody>';
            
            for ($i = 0; $i < count($entry['all_fields']); $i++) {
                $value = $entry['all_fields'][$i] ?? '';
                $column_name = isset($entry['columns'][$i]) ? $entry['columns'][$i] : "veld_$i";
                
                $html .= '<tr>
                    <td class="column-index">' . $i . '</td>
                    <td class="column-name">' . htmlspecialchars($column_name) . '</td>
                    <td class="column-value">' . ($value !== '' ? nl2br(htmlspecialchars($value)) : '<span class="empty-field">(leeg)</span>') . '</td>
                </tr>';
            }
            
            $html .= '</tbody>
                </table>';
            
            $html .= '</div>';
            
            // Pagina break na elke 2 entries
            if (($index + 1) % 2 === 0 && ($index + 1) < count($dpia_entries)) {
                $html .= '<div class="page-break"></div>';
            }
        }
        
        $html .= '</div>';
    }
    
    // Samenvatting
    $html .= '<div class="page-break"></div>
        <div class="section print-optimize">
            <h2>3. Samenvatting en Statistieken</h2>
            
            <h3>Risico Verdeling</h3>
            <table class="details-table">
                <thead>
                    <tr>
                        <th>Risiconiveau</th>
                        <th>GDPR</th>
                        <th>DPIA</th>
                        <th>Totaal</th>
                    </tr>
                </thead>
                <tbody>';
    
    // Definieer risiconiveaus
    $risk_levels = ['High', 'Medium', 'Low', 'Unknown'];
    $risk_counts = [
        'High' => ['gdpr' => 0, 'dpia' => 0],
        'Medium' => ['gdpr' => 0, 'dpia' => 0],
        'Low' => ['gdpr' => 0, 'dpia' => 0],
        'Unknown' => ['gdpr' => 0, 'dpia' => 0]
    ];
    
    // Tel risico\'s
    foreach ($entries as $entry) {
        if ($entry['type'] === 'gdpr') {
            $risk = !empty($entry['risk_level']) ? $entry['risk_level'] : 'Unknown';
            $risk_key = ucfirst(strtolower($risk));
            if (isset($risk_counts[$risk_key])) {
                $risk_counts[$risk_key]['gdpr']++;
            } else {
                $risk_counts['Unknown']['gdpr']++;
            }
        } elseif ($entry['type'] === 'dpia') {
            $risk = !empty($entry['overall_risk_level']) ? $entry['overall_risk_level'] : 'Unknown';
            $risk_key = ucfirst(strtolower($risk));
            if (isset($risk_counts[$risk_key])) {
                $risk_counts[$risk_key]['dpia']++;
            } else {
                $risk_counts['Unknown']['dpia']++;
            }
        }
    }
    
    // Toon risico tellingen
    foreach ($risk_counts as $risk => $counts) {
        $total = $counts['gdpr'] + $counts['dpia'];
        if ($total > 0) {
            $risk_class = strtolower($risk);
            $html .= '<tr>
                <td><span class="badge badge-' . $risk_class . '">' . htmlspecialchars($risk) . '</span></td>
                <td>' . $counts['gdpr'] . '</td>
                <td>' . $counts['dpia'] . '</td>
                <td><strong>' . $total . '</strong></td>
            </tr>';
        }
    }
    
    $html .= '</tbody>
            </table>
            
            <h3>Status Overzicht</h3>
            <table class="details-table">
                <thead>
                    <tr>
                        <th>Status</th>
                        <th>Aantal</th>
                    </tr>
                </thead>
                <tbody>';
    
    $status_counts = [];
    foreach ($entries as $entry) {
        $status = '';
        if ($entry['type'] === 'gdpr' && !empty($entry['status'])) {
            $status = $entry['status'];
        } elseif ($entry['type'] === 'dpia' && !empty($entry['status'])) {
            $status = $entry['status'];
        }
        
        if ($status !== '') {
            $status_counts[$status] = ($status_counts[$status] ?? 0) + 1;
        }
    }
    
    arsort($status_counts);
    foreach ($status_counts as $status => $count) {
        $html .= '<tr>
            <td>' . htmlspecialchars($status) . '</td>
            <td>' . $count . '</td>
        </tr>';
    }
    
    $html .= '</tbody>
            </table>
            
            <h3>Bestanden Overzicht</h3>
            <table class="details-table">
                <thead>
                    <tr>
                        <th>Bestand</th>
                        <th>GDPR</th>
                        <th>DPIA</th>
                        <th>Totaal</th>
                    </tr>
                </thead>
                <tbody>';
    
    $file_counts = [];
    foreach ($entries as $entry) {
        $file = $entry['file'];
        if (!isset($file_counts[$file])) {
            $file_counts[$file] = ['gdpr' => 0, 'dpia' => 0, 'unknown' => 0];
        }
        $file_counts[$file][$entry['type']]++;
    }
    
    foreach ($file_counts as $file => $counts) {
        $total = array_sum($counts);
        $html .= '<tr>
            <td>' . htmlspecialchars($file) . '</td>
            <td>' . $counts['gdpr'] . '</td>
            <td>' . $counts['dpia'] . '</td>
            <td><strong>' . $total . '</strong></td>
        </tr>';
    }
    
    $html .= '</tbody>
            </table>
        </div>
        
        <div class="footer">
            <strong>GDPR & DPIA Register - Compleet Overzicht</strong><br>
            Document gegenereerd op ' . date('d-m-Y H:i:s') . ' | ' . count($entries) . ' entries uit ' . count($file_counts) . ' bestanden<br>
            Gebruik de print-functie van uw browser om een PDF te maken (Ctrl+P of Cmd+P)
        </div>
    </div>
    
    <script>
        // Auto-print na laden
        window.onload = function() {
            // Uncomment deze regel voor automatisch printen:
            // setTimeout(function() { window.print(); }, 1000);
        };
        
        // Responsive adjustments
        function adjustForMobile() {
            if (window.innerWidth <= 768) {
                // Hide some columns on mobile
                document.querySelectorAll(".all-fields-table .column-index").forEach(el => {
                    el.style.display = "none";
                });
            }
        }
        
        // Initial adjustment
        adjustForMobile();
        
        // Adjust on resize
        window.addEventListener("resize", adjustForMobile);
        
        // Toggle raw data view
        document.addEventListener("click", function(e) {
            if (e.target.classList.contains("toggle-raw")) {
                const rawDiv = e.target.nextElementSibling;
                rawDiv.classList.toggle("show");
            }
        });
    </script>
</body>
</html>';
    
    return $html;
}
?>