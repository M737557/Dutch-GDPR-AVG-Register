<?php
// ============================================
// Extract ALL organizational_measures from GDPR txt files
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 1);

$data_directory = __DIR__ . '/dutch/';

if (!is_dir($data_directory)) {
    die('Data directory not found: ' . htmlspecialchars($data_directory));
}

// Haal alle organizational_measures op
$organizational_measures = [];

$files = getAllDataFiles($data_directory);

foreach ($files as $file) {
    $entries = parseFileContent($file);
    
    foreach ($entries as $entry) {
        if ($entry['type'] === 'gdpr' && !empty($entry['organizational_measures'])) {
            $organizational_measures[] = [
                'id' => $entry['id'],
                'processing_activity' => $entry['processing_activity'] ?? 'Onbekend',
                'organizational_measures' => $entry['organizational_measures'],
                'file' => basename($file),
                'risk_level' => $entry['risk_level'] ?? 'unknown'
            ];
        }
    }
}

// Display the results
displayResults($organizational_measures);

// ============================================
// Helper Functions
// ============================================

function getAllDataFiles($directory) {
    $files = [];
    if (is_dir($directory)) {
        $all_files = scandir($directory);
        foreach ($all_files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'txt' && $file !== '.' && $file !== '..') {
                $files[] = $directory . $file;
            }
        }
    }
    return $files;
}

function parseFileContent($filepath) {
    $entries = [];
    
    if (!file_exists($filepath)) {
        return $entries;
    }
    
    if (filesize($filepath) > 10485760) { // 10MB max
        return $entries;
    }
    
    $content = @file_get_contents($filepath);
    if ($content === false) {
        return $entries;
    }
    
    $lines = explode("\n", $content);
    
    foreach ($lines as $line) {
        $trimmed = trim($line);
        if (strpos($trimmed, '--') === 0 || $trimmed === '' || strpos($trimmed, 'INSERT INTO') !== false) {
            continue;
        }
        
        if (strpos($trimmed, '(') === 0) {
            $data = parseDataRow($trimmed);
            if ($data && count($data) >= 33) { // GDPR has 33+ fields
                $entry = parseGdprEntry($data);
                if ($entry) {
                    $entries[] = $entry;
                }
            }
        }
    }
    
    return $entries;
}

function parseDataRow($line) {
    $line = trim($line, ");\n\r\t");
    $line = trim($line, "),");
    
    $values = [];
    $current = '';
    $in_quotes = false;
    $escaped = false;
    
    for ($i = 0; $i < strlen($line); $i++) {
        $char = $line[$i];
        
        if ($char === '\\') {
            $escaped = !$escaped;
            $current .= $char;
        } elseif ($char === "'" && !$escaped) {
            $in_quotes = !$in_quotes;
            $current .= $char;
        } elseif ($char === ',' && !$in_quotes && !$escaped) {
            $values[] = trim($current, "'");
            $current = '';
        } else {
            $current .= $char;
            $escaped = false;
        }
    }
    
    if ($current !== '') {
        $values[] = trim($current, "'");
    }
    
    return $values;
}

function parseGdprEntry($data) {
    $gdpr_columns = [
        'id', 'has_processing_agreement_with_third_party', 'we_are_processor', 'processing_activity', 'name_data_controller',
        'contact_data_controller', 'name_joint_data_controller', 'contact_joint_data_controller', 'name_representative',
        'contact_representative', 'name_dpo', 'contact_dpo', 'purpose_of_processing', 'legal_basis',
        'categories_personal_data', 'categories_data_subjects', 'categories_recipients', 'retention_periods',
        'risk_level', 'technical_measures', 'organizational_measures', 'dpia_required', 'is_international_data_transfers',
        'to_country', 'safeguards', 'created_at', 'updated_at', 'review_due_date', 'created_by', 'updated_by',
        'department', 'status', 'legitimate_interest_description', 'dpia_status'
    ];
    
    $entry = ['type' => 'gdpr'];
    
    // Map all fields to column names
    for ($i = 0; $i < min(count($data), count($gdpr_columns)); $i++) {
        $column_name = $gdpr_columns[$i];
        $entry[$column_name] = $data[$i] ?? '';
    }
    
    return $entry;
}

function displayResults($measures) {
    ?>
    <!DOCTYPE html>
    <html lang="nl">
    <head>
        <meta charset="UTF-8">
        <title>Organizational Measures - GDPR Register</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: #f0f2f5;
                padding: 20px;
                line-height: 1.5;
            }
            
            .container {
                max-width: 1400px;
                margin: 0 auto;
                background: white;
                border-radius: 12px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                overflow: hidden;
            }
            
            .header {
                background: linear-gradient(135deg, #1a3a5c, #2c5a7a);
                color: white;
                padding: 25px 30px;
            }
            
            .header h1 {
                font-size: 24px;
                margin-bottom: 8px;
            }
            
            .header p {
                font-size: 14px;
                opacity: 0.9;
            }
            
            .stats {
                background: #e8f4fc;
                padding: 15px 30px;
                border-bottom: 1px solid #cde4f0;
                display: flex;
                gap: 30px;
                flex-wrap: wrap;
            }
            
            .stat {
                display: flex;
                align-items: baseline;
                gap: 8px;
            }
            
            .stat-number {
                font-size: 28px;
                font-weight: bold;
                color: #1a3a5c;
            }
            
            .stat-label {
                font-size: 14px;
                color: #4a6a8a;
            }
            
            .export-btn {
                background: #2c5a7a;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 6px;
                cursor: pointer;
                font-size: 13px;
                transition: background 0.2s;
                margin-left: auto;
            }
            
            .export-btn:hover {
                background: #1a3a5c;
            }
            
            table {
                width: 100%;
                border-collapse: collapse;
            }
            
            th {
                background: #f8f9fc;
                padding: 14px 12px;
                text-align: left;
                font-weight: 600;
                color: #2c3e50;
                border-bottom: 2px solid #e0e4e8;
                position: sticky;
                top: 0;
                background: #f8f9fc;
            }
            
            td {
                padding: 14px 12px;
                border-bottom: 1px solid #e9ecef;
                vertical-align: top;
            }
            
            tr:hover {
                background: #f8f9fc;
            }
            
            .badge {
                display: inline-block;
                padding: 4px 10px;
                border-radius: 20px;
                font-size: 11px;
                font-weight: 600;
            }
            
            .badge-high {
                background: #fee2e2;
                color: #dc2626;
            }
            
            .badge-medium {
                background: #fef3c7;
                color: #d97706;
            }
            
            .badge-low {
                background: #d1fae5;
                color: #059669;
            }
            
            .badge-unknown {
                background: #e5e7eb;
                color: #6b7280;
            }
            
            .measures-cell {
                max-width: 500px;
                word-wrap: break-word;
                white-space: normal;
                line-height: 1.5;
            }
            
            .id-cell {
                font-weight: 600;
                color: #1a3a5c;
                text-align: center;
            }
            
            .activity-cell {
                font-weight: 500;
                max-width: 300px;
            }
            
            .file-cell {
                font-family: monospace;
                font-size: 11px;
                color: #6c757d;
            }
            
            .footer {
                background: #f8f9fc;
                padding: 15px 30px;
                text-align: center;
                font-size: 12px;
                color: #6c757d;
                border-top: 1px solid #e0e4e8;
            }
            
            @media (max-width: 768px) {
                body {
                    padding: 10px;
                }
                
                .header h1 {
                    font-size: 18px;
                }
                
                th, td {
                    padding: 10px 8px;
                    font-size: 12px;
                }
                
                .stats {
                    flex-direction: column;
                    gap: 8px;
                }
                
                .export-btn {
                    margin-left: 0;
                    width: fit-content;
                }
            }
            
            @media print {
                body {
                    background: white;
                    padding: 0;
                }
                
                .export-btn, .stats {
                    display: none;
                }
                
                table {
                    font-size: 9pt;
                }
                
                th, td {
                    padding: 6px 4px;
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>📋 Organizational Measures - GDPR Register</h1>
                <p>Overzicht van alle organisatorische beveiligingsmaatregelen per verwerkingsactiviteit</p>
            </div>
            
            <div class="stats">
                <div class="stat">
                    <span class="stat-number"><?php echo count($measures); ?></span>
                    <span class="stat-label">GDPR Verwerkingen met Organizational Measures</span>
                </div>
                <div class="stat">
                    <span class="stat-number">
                        <?php 
                        $high = count(array_filter($measures, function($m) { 
                            return strtolower($m['risk_level']) === 'high'; 
                        }));
                        echo $high;
                        ?>
                    </span>
                    <span class="stat-label">High Risk</span>
                </div>
                <div class="stat">
                    <span class="stat-number">
                        <?php 
                        $medium = count(array_filter($measures, function($m) { 
                            return strtolower($m['risk_level']) === 'medium'; 
                        }));
                        echo $medium;
                        ?>
                    </span>
                    <span class="stat-label">Medium Risk</span>
                </div>
                <div class="stat">
                    <span class="stat-number">
                        <?php 
                        $low = count(array_filter($measures, function($m) { 
                            return strtolower($m['risk_level']) === 'low'; 
                        }));
                        echo $low;
                        ?>
                    </span>
                    <span class="stat-label">Low Risk</span>
                </div>
                <button class="export-btn" onclick="copyToClipboard()">📋 Copy All</button>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th style="width: 60px">ID</th>
                        <th style="width: 250px">Verwerkingsactiviteit</th>
                        <th>Organisatorische Maatregelen</th>
                        <th style="width: 100px">Risico</th>
                        <th style="width: 150px">Bronbestand</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($measures) === 0): ?>
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 40px;">
                                ❌ Geen organizational_measures gevonden in de txt bestanden.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($measures as $measure): ?>
                            <tr>
                                <td class="id-cell"><?php echo htmlspecialchars($measure['id']); ?></td>
                                <td class="activity-cell"><?php echo htmlspecialchars($measure['processing_activity']); ?></td>
                                <td class="measures-cell">
                                    <?php 
                                    $measures_text = htmlspecialchars($measure['organizational_measures']);
                                    // Convert commas to line breaks for better readability
                                    $measures_text = str_replace(', ', ",\n", $measures_text);
                                    echo nl2br($measures_text);
                                    ?>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo strtolower($measure['risk_level']); ?>">
                                        <?php echo ucfirst(htmlspecialchars($measure['risk_level'])); ?>
                                    </span>
                                </td>
                                <td class="file-cell"><?php echo htmlspecialchars($measure['file']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <div class="footer">
                <strong>GDPR Register - Organizational Measures</strong><br>
                Gegenereerd op <?php echo date('d-m-Y H:i:s'); ?> | Totaal <?php echo count($measures); ?> entries
            </div>
        </div>
        
        <script>
            function copyToClipboard() {
                let text = "ID\tVerwerkingsactiviteit\tOrganisatorische Maatregelen\tRisico\tBronbestand\n";
                text += "===\t===================\t==========================\t=====\t==========\n";
                
                <?php foreach ($measures as $measure): ?>
                text += "<?php echo $measure['id']; ?>\t";
                text += "<?php echo addslashes($measure['processing_activity']); ?>\t";
                text += "<?php echo addslashes($measure['organizational_measures']); ?>\t";
                text += "<?php echo $measure['risk_level']; ?>\t";
                text += "<?php echo $measure['file']; ?>\n";
                <?php endforeach; ?>
                
                navigator.clipboard.writeText(text).then(function() {
                    alert("✅ Alle organizational_measures zijn gekopieerd naar het klembord!");
                }, function() {
                    alert("❌ Kon niet kopiëren naar klembord.");
                });
            }
        </script>
    </body>
    </html>
    <?php
}
?>