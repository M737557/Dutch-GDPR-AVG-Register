<?php
$regels = file('processing_activities_only.txt', FILE_IGNORE_NEW_LINES);
$html = '';

foreach ($regels as $regel) {
    $html .= '<li>' . htmlspecialchars($regel) . '</li>' . PHP_EOL;
}

echo '<ul>' . PHP_EOL . $html . '</ul>';
?>