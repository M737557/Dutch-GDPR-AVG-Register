<?php
$directory = './'; // Directory met tekstbestanden

// Haal alle .txt bestanden op
$files = glob($directory . '*.txt');

if (empty($files)) {
    die("<h2>❌ Geen .txt bestanden gevonden in de directory: $directory</h2>");
}

// Combineer alle bestanden
$alleInhoud = '';
foreach ($files as $bestand) {
    $alleInhoud .= file_get_contents($bestand) . " ";
}

// Woordfrequentie analyse
$woorden = str_word_count(strtolower($alleInhoud), 1);
$frequentie = array_count_values($woorden);
arsort($frequentie);
$topWoorden = array_slice($frequentie, 0, 30);

// Bestandsoverzicht voor statistieken
$aantalBestanden = count($files);
$totaalWoorden = array_sum($frequentie);
$uniekeWoorden = count($frequentie);
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        * {
            font-family: 'Segoe UI', 'Arial', 'Helvetica', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: #ffffff;
            color: #000000;
            line-height: 1.5;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px 20px;
        }
        
        /* Zakelijke header */
        .header {
            border-bottom: 2px solid #000000;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        h1 {
            font-size: 28px;
            font-weight: 600;
            color: #000000;
            letter-spacing: -0.5px;
            margin-bottom: 10px;
        }
        
        .subtitle {
            color: #555555;
            font-size: 14px;
        }
        
        /* Statistieken grid */
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1px;
            margin: 30px 0;
            background: #e0e0e0;
            border: 1px solid #e0e0e0;
        }
        
        .stat-card {
            background: #ffffff;
            padding: 25px;
            text-align: center;
        }
        
        .stat-card h3 {
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #666666;
            margin-bottom: 12px;
        }
        
        .stat-card .number {
            font-size: 36px;
            font-weight: 700;
            color: #000000;
        }
        
        .stat-card .unit {
            font-size: 14px;
            color: #666666;
            margin-left: 5px;
        }
        
        /* Bestandslijst */
        .file-list {
            background: #f8f8f8;
            border: 1px solid #e0e0e0;
            padding: 20px;
            margin: 30px 0;
        }
        
        .file-list h3 {
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #000000;
            margin-bottom: 15px;
        }
        
        .file-list ul {
            columns: 4;
            list-style: none;
            padding: 0;
        }
        
        .file-list li {
            padding: 5px 0;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            color: #333333;
            border-bottom: 1px dotted #e0e0e0;
        }
        
        /* Zakelijke heatmap - grijstinten */
        .heatmap {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(100px, auto));
            gap: 1px;
            background: #e0e0e0;
            border: 1px solid #e0e0e0;
            margin: 30px 0;
        }
        
        .word-card {
            background: #ffffff;
            padding: 15px 10px;
            text-align: center;
            transition: all 0.2s ease;
        }
        
        .word-card:hover {
            background: #f0f0f0;
            transform: translateY(-2px);
        }
        
        .word {
            font-weight: 600;
            font-size: 13px;
            color: #000000;
            text-transform: lowercase;
        }
        
        .count {
            font-size: 11px;
            color: #888888;
            margin-top: 5px;
            font-family: 'Courier New', monospace;
        }
        
        /* Tabel stijlen */
        .section-title {
            font-size: 18px;
            font-weight: 600;
            margin: 40px 0 20px 0;
            padding-bottom: 10px;
            border-bottom: 2px solid #000000;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        .data-table th {
            background: #000000;
            color: #ffffff;
            padding: 12px;
            text-align: left;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .data-table td {
            padding: 12px;
            border-bottom: 1px solid #e0e0e0;
            color: #333333;
            font-size: 14px;
        }
        
        .data-table tr:hover {
            background: #f8f8f8;
        }
        
        .rank {
            font-weight: 700;
            color: #000000;
            width: 50px;
        }
        
        .word-cell {
            font-weight: 600;
            color: #000000;
        }
        
        .count-cell {
            font-family: 'Courier New', monospace;
            font-weight: 600;
        }
        
        .percentage-cell {
            font-family: 'Courier New', monospace;
            color: #555555;
        }
        
        /* Zakelijke balkgrafiek */
        .bar-container {
            background: #e8e8e8;
            height: 24px;
            width: 100%;
            position: relative;
        }
        
        .bar {
            background: #000000;
            height: 100%;
            transition: width 0.3s ease;
            position: relative;
        }
        
        .bar-label {
            position: absolute;
            right: 8px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 11px;
            font-weight: 600;
            color: #ffffff;
            z-index: 1;
        }
        
        /* Footer */
        .footer {
            margin-top: 60px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
            text-align: center;
            font-size: 11px;
            color: #999999;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                padding: 20px 15px;
            }
            
            .heatmap {
                grid-template-columns: repeat(auto-fill, minmax(80px, auto));
            }
            
            .file-list ul {
                columns: 2;
            }
            
            .stat-card .number {
                font-size: 28px;
            }
            
            .data-table th,
            .data-table td {
                padding: 8px;
                font-size: 12px;
            }
        }
        
        @media print {
            body {
                background: white;
            }
            
            .word-card:hover {
                transform: none;
            }
            
            .bar {
                background: #000000 !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>WORD FREQUENCY ANALYSIS REPORT</h1>
            <div class="subtitle">Complete directory analysis | <?= date('Y-m-d H:i:s') ?></div>
        </div>
        
        <div class="stats">
            <div class="stat-card">
                <h3>FILES ANALYZED</h3>
                <div class="number"><?= $aantalBestanden ?></div>
            </div>
            <div class="stat-card">
                <h3>TOTAL WORDS</h3>
                <div class="number"><?= number_format($totaalWoorden) ?></div>
            </div>
            <div class="stat-card">
                <h3>UNIQUE WORDS</h3>
                <div class="number"><?= number_format($uniekeWoorden) ?></div>
            </div>
            <div class="stat-card">
                <h3>MOST FREQUENT</h3>
                <div class="number" style="font-size: 24px;">"<?= htmlspecialchars(key($topWoorden)) ?>"</div>
                <div style="font-size: 12px; color: #666;"><?= current($topWoorden) ?> occurrences</div>
            </div>
        </div>
        
        <div class="file-list">
            <h3>📄 SOURCE FILES</h3>
            <ul>
                <?php foreach ($files as $bestand): ?>
                    <li><?= htmlspecialchars(basename($bestand)) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        
        <div>
            <div class="section-title">WORD FREQUENCY HEATMAP (TOP 30)</div>
            <div class="heatmap">
                <?php
                $maxCount = max($topWoorden);
                foreach ($topWoorden as $woord => $count):
                    // Bepaal grijswaarde (zwart = meest frequent, lichtgrijs = minst frequent)
                    $intensity = 255 - (($count / $maxCount) * 200);
                    $grayValue = max(55, min(255, $intensity));
                    $bgColor = "rgb($grayValue, $grayValue, $grayValue)";
                    $textColor = $grayValue < 128 ? '#ffffff' : '#000000';
                ?>
                <div class="word-card" style="background-color: <?= $bgColor ?>;" title="'<?= $woord ?>' occurs <?= $count ?> times across all files">
                    <div class="word" style="color: <?= $textColor ?>;"><?= htmlspecialchars($woord) ?></div>
                    <div class="count" style="color: <?= $textColor ?>; opacity: 0.7;"><?= $count ?>x</div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div>
            <div class="section-title">TOP 20 FREQUENCY RANKING</div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>RANK</th>
                        <th>WORD</th>
                        <th>COUNT</th>
                        <th>FREQUENCY</th>
                        <th>DISTRIBUTION</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $rank = 1;
                    $top20 = array_slice($topWoorden, 0, 20);
                    foreach ($top20 as $woord => $count): 
                        $percentage = ($count / $totaalWoorden) * 100;
                        $barWidth = ($count / $maxCount) * 100;
                    ?>
                    <tr>
                        <td class="rank"><?= $rank++ ?></td>
                        <td class="word-cell"><?= htmlspecialchars($woord) ?></td>
                        <td class="count-cell"><?= number_format($count) ?></td>
                        <td class="percentage-cell"><?= number_format($percentage, 2) ?>%</td>
                        <td style="width: 35%;">
                            <div class="bar-container">
                                <div class="bar" style="width: <?= $barWidth ?>%;"></div>
                                <span class="bar-label"><?= round($barWidth) ?>%</span>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div class="footer">
            <p>ANALYSIS REPORT | Generated by Word Frequency Analyzer | <?= $aantalBestanden ?> files processed | <?= number_format($totaalWoorden) ?> total words</p>
            <p style="margin-top: 10px;">© <?= date('Y') ?> Professional Text Analytics</p>
        </div>
    </div>
</body>
</html>