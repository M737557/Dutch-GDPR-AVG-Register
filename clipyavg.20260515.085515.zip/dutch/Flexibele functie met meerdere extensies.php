<?php
function listFilesByExtensions($directory, $extensies = []) {
    $resultaten = [];
    $bestanden = array_diff(scandir($directory), ['.', '..']);
    
    foreach ($bestanden as $bestand) {
        $path = $directory . '/' . $bestand;
        
        if (is_file($path)) {
            $ext = strtolower(pathinfo($bestand, PATHINFO_EXTENSION));
            if (empty($extensies) || in_array($ext, $extensies)) {
                $resultaten[] = [
                    'naam' => $bestand,
                    'pad' => $path,
                    'extensie' => $ext,
                    'grootte' => filesize($path),
                    'gewijzigd' => filemtime($path)
                ];
            }
        }
    }
    
    return $resultaten;
}

// Voorbeelden:
$alleTxtFiles = listFilesByExtensions('./', ['txt']);
$alleAfbeeldingen = listFilesByExtensions('./', ['jpg', 'png', 'gif', 'webp']);
$alleWebFiles = listFilesByExtensions('./', ['php', 'html', 'css', 'js']);

// Weergeven:
foreach ($alleWebFiles as $file) {
    echo $file['naam'] . ' (' . $file['extensie'] . ') - ' . $file['grootte'] . ' bytes<br>' . "\n";
}
?>