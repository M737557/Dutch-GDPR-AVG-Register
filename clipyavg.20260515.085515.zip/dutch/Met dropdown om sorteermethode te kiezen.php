<?php
$directory = './';
$toegestaneExtensies = ['txt', 'php', 'html', 'css', 'js'];

// Sorteermethode uit URL (default = extensie)
$sorteerOp = $_GET['sorteer'] ?? 'extensie';
$sorteerVolgorde = $_GET['volgorde'] ?? 'oplopend';

// Functie voor human readable bestandsgroottes
function formatteerGrootte($bytes) {
    if ($bytes === 0) return '0 B';
    
    $eenheden = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = floor(log($bytes, 1024));
    $grootte = $bytes / pow(1024, $i);
    
    // Afronden op 2 decimalen
    return round($grootte, 2) . ' ' . $eenheden[$i];
}

// Functie om te sorteren op basis van originele bytes (niet de formatted string)
function getGrootteInBytes($bestand) {
    return $bestand['grootte'];
}

$files = array_diff(scandir($directory), ['.', '..']);

$bestandInfo = [];

foreach ($files as $file) {
    $path = $directory . '/' . $file;
    
    if (is_file($path)) {
        $extensie = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($extensie, $toegestaneExtensies)) {
            $bestandInfo[] = [
                'naam' => $file,
                'extensie' => $extensie,
                'grootte' => filesize($path),  // Originele bytes voor sortering
                'grootteLeesbaar' => formatteerGrootte(filesize($path)), // Human readable
                'datum' => filemtime($path)
            ];
        }
    }
}

// Sorteren op gekozen veld met volgorde
usort($bestandInfo, function($a, $b) use ($sorteerOp, $sorteerVolgorde) {
    $result = 0;
    
    switch ($sorteerOp) {
        case 'naam':
            $result = strcmp($a['naam'], $b['naam']);
            break;
        case 'grootte':
            $result = $a['grootte'] - $b['grootte'];  // Sorteer op bytes
            break;
        case 'datum':
            $result = $a['datum'] - $b['datum'];
            break;
        case 'extensie':
        default:
            $result = strcmp($a['extensie'], $b['extensie']);
    }
    
    // Aflopend = resultaat omkeren
    return ($sorteerVolgorde === 'aflopend') ? -$result : $result;
});

// HTML met sorteermenu
echo '<form method="get" style="margin-bottom: 20px;">';
echo '<label>Sorteer op: </label>';
echo '<select name="sorteer">';
echo '<option value="extensie" ' . ($sorteerOp == 'extensie' ? 'selected' : '') . '>Extensie</option>';
echo '<option value="naam" ' . ($sorteerOp == 'naam' ? 'selected' : '') . '>Bestandsnaam</option>';
echo '<option value="grootte" ' . ($sorteerOp == 'grootte' ? 'selected' : '') . '>Grootte</option>';
echo '<option value="datum" ' . ($sorteerOp == 'datum' ? 'selected' : '') . '>Laatste wijziging</option>';
echo '</select>';

echo '<label style="margin-left: 10px;">Volgorde: </label>';
echo '<select name="volgorde">';
echo '<option value="oplopend" ' . ($sorteerVolgorde == 'oplopend' ? 'selected' : '') . '>Oplopend (A→Z / Klein→Groot)</option>';
echo '<option value="aflopend" ' . ($sorteerVolgorde == 'aflopend' ? 'selected' : '') . '>Aflopend (Z→A / Groot→Klein)</option>';
echo '</select>';

echo '<button type="submit">Sorteer</button>';
echo '</form>';

// Tabel met human readable groottes
echo '<table border="1" cellpadding="8" cellspacing="0" style="border-collapse: collapse;">';
echo '<tr style="background-color: #4CAF50; color: white;">';
echo '<th>Bestand</th><th>Extensie</th><th>Grootte</th><th>Laatste wijziging</th>';
echo '</tr>';

foreach ($bestandInfo as $info) {
    echo '<tr>';
    echo '<td>' . htmlspecialchars($info['naam']) . '</td>';
    echo '<td>.' . $info['extensie'] . '</td>';
    echo '<td>' . $info['grootteLeesbaar'] . ' ';  // Human readable hier
    echo '<td>' . date('Y-m-d H:i:s', $info['datum']) . '</td>';
    echo '</tr>';
}

echo '</table>';
echo '<p><strong>Totaal:</strong> ' . count($bestandInfo) . ' bestanden</p>';
?>