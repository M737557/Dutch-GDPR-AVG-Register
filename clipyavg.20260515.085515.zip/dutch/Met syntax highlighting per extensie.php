<?php
$directory = './';
$toegestaneExtensies = ['txt', 'php', 'html', 'css', 'js'];

$files = array_diff(scandir($directory), ['.', '..']);

$bestandInfo = [];

foreach ($files as $file) {
    $path = $directory . '/' . $file;
    
    if (is_file($path)) {
        $extensie = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($extensie, $toegestaneExtensies)) {
            $inhoud = file_get_contents($path);
            $snippet = substr(trim($inhoud), 0, 150);
            
            // Eenvoudige syntax highlighting
            switch ($extensie) {
                case 'php':
                    $snippet = highlight_string("<?php\n" . $snippet . "\n?>", true);
                    break;
                case 'html':
                    $snippet = htmlspecialchars($snippet);
                    break;
                case 'css':
                case 'js':
                    $snippet = '<pre style="color: #0066cc;">' . htmlspecialchars($snippet) . '</pre>';
                    break;
                default:
                    $snippet = htmlspecialchars($snippet);
            }
            
            $bestandInfo[] = [
                'naam' => $file,
                'extensie' => $extensie,
                'grootte' => filesize($path),
                'datum' => filemtime($path),
                'snippet' => $snippet
            ];
        }
    }
}

usort($bestandInfo, function($a, $b) {
    return strcmp($a['extensie'], $b['extensie']);
});

echo '<style>
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; vertical-align: top; }
    th { background-color: #4CAF50; color: white; }
    td pre { margin: 0; }
</style>';

echo '<table>';
echo '<tr><th>Bestand</th><th>Extensie</th><th>Grootte</th><th>Datum</th><th>Snippet</th></tr>';

foreach ($bestandInfo as $info) {
    echo '<tr>';
    echo '<td>' . htmlspecialchars($info['naam']) . '</td>';
    echo '<td>.' . $info['extensie'] . '</td>';
    echo '<td>' . number_format($info['grootte']) . ' B</td>';
    echo '<td>' . date('H:i:s', $info['datum']) . '</td>';
    echo '<td>' . $info['snippet'] . '</td>';
    echo '</tr>';
}

echo '</table>';
?>