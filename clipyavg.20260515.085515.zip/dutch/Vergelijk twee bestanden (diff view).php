<?php
$directory = './';
$bestand1 = $_GET['file1'] ?? '';
$bestand2 = $_GET['file2'] ?? '';
$files = glob($directory . '*.txt');
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        .diff-container {
            display: flex;
            gap: 20px;
            margin-top: 20px;
        }
        .diff-panel {
            flex: 1;
            background: #f5f5f5;
            padding: 15px;
            border-radius: 8px;
            overflow-x: auto;
        }
        .diff-line {
            font-family: monospace;
            font-size: 12px;
            padding: 2px 5px;
            margin: 0;
            white-space: pre-wrap;
        }
        .diff-added {
            background-color: #d4ffd4;
        }
        .diff-removed {
            background-color: #ffd4d4;
        }
        .line-number {
            display: inline-block;
            width: 40px;
            color: #999;
            user-select: none;
        }
        select, button { padding: 8px; margin: 5px; }
    </style>
</head>
<body>
    <h2>🔍 File Diff Tool</h2>
    
    <form method="get">
        <select name="file1">
            <option value="">Kies bestand 1</option>
            <?php foreach ($files as $f): ?>
                <option value="<?= basename($f) ?>" <?= $bestand1 == basename($f) ? 'selected' : '' ?>>
                    <?= basename($f) ?>
                </option>
            <?php endforeach; ?>
        </select>
        
        <select name="file2">
            <option value="">Kies bestand 2</option>
            <?php foreach ($files as $f): ?>
                <option value="<?= basename($f) ?>" <?= $bestand2 == basename($f) ? 'selected' : '' ?>>
                    <?= basename($f) ?>
                </option>
            <?php endforeach; ?>
        </select>
        
        <button type="submit">Vergelijk</button>
    </form>
    
    <?php if ($bestand1 && $bestand2 && file_exists($bestand1) && file_exists($bestand2)): 
        $lines1 = file($bestand1, FILE_IGNORE_NEW_LINES);
        $lines2 = file($bestand2, FILE_IGNORE_NEW_LINES);
        $diff = array_diff($lines1, $lines2);
        $diff2 = array_diff($lines2, $lines1);
    ?>
    
    <div class="diff-container">
        <div class="diff-panel">
            <h3>📄 <?= htmlspecialchars($bestand1) ?> (<?= count($lines1) ?> regels)</h3>
            <?php foreach ($lines1 as $num => $line): ?>
                <div class="diff-line <?= in_array($line, $diff) ? 'diff-removed' : '' ?>">
                    <span class="line-number"><?= $num+1 ?></span>
                    <?= htmlspecialchars($line) ?>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="diff-panel">
            <h3>📄 <?= htmlspecialchars($bestand2) ?> (<?= count($lines2) ?> regels)</h3>
            <?php foreach ($lines2 as $num => $line): ?>
                <div class="diff-line <?= in_array($line, $diff2) ? 'diff-added' : '' ?>">
                    <span class="line-number"><?= $num+1 ?></span>
                    <?= htmlspecialchars($line) ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <div style="margin-top: 20px; padding: 15px; background: #e3f2fd; border-radius: 8px;">
        <strong>📊 Samenvatting:</strong><br>
        - Alleen in <?= basename($bestand1) ?>: <?= count($diff) ?> regels<br>
        - Alleen in <?= basename($bestand2) ?>: <?= count($diff2) ?> regels<br>
        - Gemeenschappelijke regels: <?= count(array_intersect($lines1, $lines2)) ?> regels
    </div>
    
    <?php endif; ?>
</body>
</html>