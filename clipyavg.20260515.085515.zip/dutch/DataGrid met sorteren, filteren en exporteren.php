<?php
$directory = './';
$toegestaneExtensies = ['txt', 'php', 'html', 'css', 'js', 'json', 'csv', 'log', 'md'];

$files = array_diff(scandir($directory), ['.', '..']);
$dataset = [];

foreach ($files as $file) {
    $path = $directory . '/' . $file;
    if (is_file($path)) {
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($ext, $toegestaneExtensies)) {
            $inhoud = file_get_contents($path);
            $dataset[] = [
                'naam' => $file,
                'extensie' => $ext,
                'grootte' => filesize($path),
                'grootte_kb' => round(filesize($path) / 1024, 2),
                'regels' => count(file($path, FILE_IGNORE_NEW_LINES)),
                'woorden' => str_word_count($inhoud),
                'tekens' => strlen($inhoud),
                'datum' => date('Y-m-d H:i:s', filemtime($path)),
                'timestamp' => filemtime($path)
            ];
        }
    }
}

// Sorteren via GET
$sortColumn = $_GET['sort'] ?? 'naam';
$sortOrder = $_GET['order'] ?? 'asc';
usort($dataset, function($a, $b) use ($sortColumn, $sortOrder) {
    if ($sortOrder == 'asc') {
        return $a[$sortColumn] <=> $b[$sortColumn];
    } else {
        return $b[$sortColumn] <=> $a[$sortColumn];
    }
});

// Filteren via GET
$filterExt = $_GET['filter_ext'] ?? '';
if ($filterExt) {
    $dataset = array_filter($dataset, function($item) use ($filterExt) {
        return $item['extensie'] == $filterExt;
    });
}

// Export functionaliteit
if (isset($_GET['export'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="export_' . date('Y-m-d') . '.csv"');
    $output = fopen('php://output', 'w');
    fputcsv($output, array_keys($dataset[0]));
    foreach ($dataset as $row) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .controls { margin: 20px 0; padding: 15px; background: #f5f5f5; border-radius: 8px; }
        select, button { padding: 8px 12px; margin-right: 10px; }
        table { width: 100%; }
        th { cursor: pointer; }
        th:hover { background: #ddd; }
        .badge { display: inline-block; padding: 3px 8px; border-radius: 12px; font-size: 11px; font-weight: bold; }
        .badge-txt { background: #4CAF50; color: white; }
        .badge-php { background: #8892BF; color: white; }
        .badge-html { background: #E44D26; color: white; }
        .badge-css { background: #264DE4; color: white; }
        .badge-js { background: #F0DB4F; color: black; }
    </style>
</head>
<body>
    <h1>📁 Advanced File Datagrid</h1>
    
    <div class="controls">
        <form method="get" style="display: inline;">
            <label>Filter op extensie:</label>
            <select name="filter_ext">
                <option value="">Alle</option>
                <?php 
                $extensies = array_unique(array_column($dataset, 'extensie'));
                sort($extensies);
                foreach ($extensies as $ext): ?>
                <option value="<?= $ext ?>" <?= $filterExt == $ext ? 'selected' : '' ?>>
                    .<?= $ext ?>
                </option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Filter</button>
            <button type="button" onclick="window.location.href='?export=1'">📥 Export CSV</button>
            <button type="button" onclick="window.location.href='?'">🔄 Reset</button>
        </form>
    </div>
    
    <table id="fileTable" class="display">
        <thead>
            <tr>
                <th>📄 Bestandsnaam</th>
                <th>🔖 Extensie</th>
                <th>💾 Grootte (KB)</th>
                <th>📝 Regels</th>
                <th>📖 Woorden</th>
                <th>🔤 Tekens</th>
                <th>🕒 Laatste wijziging</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($dataset as $row): ?>
            <tr>
                <td><?= htmlspecialchars($row['naam']) ?></td>
                <td><span class="badge badge-<?= $row['extensie'] ?>">.<?= $row['extensie'] ?></span></td>
                <td><?= $row['grootte_kb'] ?></td>
                <td><?= number_format($row['regels']) ?></td>
                <td><?= number_format($row['woorden']) ?></td>
                <td><?= number_format($row['tekens']) ?></td>
                <td><?= $row['datum'] ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <script>
        $(document).ready(function() {
            $('#fileTable').DataTable({
                pageLength: 25,
                order: [[<?= 
                    $sortColumn == 'naam' ? '0' : 
                    ($sortColumn == 'extensie' ? '1' : 
                    ($sortColumn == 'grootte_kb' ? '2' : 
                    ($sortColumn == 'regels' ? '3' : 
                    ($sortColumn == 'datum' ? '6' : '0')))) 
                ?>, '<?= $sortOrder ?>']],
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.4/i18n/dutch.json'
                }
            });
        });
    </script>
</body>
</html>