<?php
$directory = './';
$uitsluiten = ['log', 'tmp', 'cache'];  // Deze extensies NIET tonen

$files = array_diff(scandir($directory), ['.', '..']);

foreach ($files as $file) {
    $path = $directory . '/' . $file;
    
    if (is_file($path)) {
        $extensie = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (!in_array($extensie, $uitsluiten)) {
            echo $file . '<br>' . "\n";
        }
    }
}
?>