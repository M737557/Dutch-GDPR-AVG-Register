<?php
// duplicate_finder.php
$directory = isset($_GET['dir']) ? $_GET['dir'] : './';
$melding = '';

// Scan directory
$bestanden = [];
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($directory));
foreach ($iterator as $file) {
    if ($file->isFile()) {
        $hash = md5_file($file->getRealPath());
        $bestanden[$hash][] = $file->getRealPath();
    }
}

// Filter duplicates
$duplicaten = array_filter($bestanden, function($files) {
    return count($files) > 1;
});
?>
<!DOCTYPE html>
<html>
<head>
    <title>🔄 Duplicate File Finder</title>
</head>
<body>
<h1>🔄 Duplicate File Finder</h1>
<p><strong>Directory:</strong> <?php echo htmlspecialchars($directory); ?></p>

<?php if (count($duplicaten) > 0): ?>
    <h2>Gevonden duplicaten (<?php echo count($duplicaten); ?> sets)</h2>
    <?php foreach ($duplicaten as $hash => $files): ?>
        <div style="border:1px solid #ccc; margin:10px; padding:10px;">
            <h3>📁 <?php echo basename($files[0]); ?></h3>
            <p>MD5: <?php echo $hash; ?></p>
            <ul>
            <?php foreach ($files as $file): ?>
                <li><?php echo htmlspecialchars($file); ?> (<?php echo round(filesize($file)/1024, 2); ?> KB)</li>
            <?php endforeach; ?>
            </ul>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <p>✅ Geen duplicaten gevonden!</p>
<?php endif; ?>
</body>
</html>