<?php
// file_search.php
$zoekterm = $_GET['zoek'] ?? '';
$resultaten = [];

if (!empty($zoekterm)) {
    $directory = new RecursiveDirectoryIterator('./');
    $iterator = new RecursiveIteratorIterator($directory);
    
    foreach ($iterator as $file) {
        if ($file->isFile() && stripos($file->getFilename(), $zoekterm) !== false) {
            $resultaten[] = [
                'naam' => $file->getFilename(),
                'pad' => $file->getPath(),
                'grootte' => $file->getSize(),
                'datum' => $file->getMTime()
            ];
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>🔍 File Search Tool</title>
    <style>
        body { font-family: Arial; margin: 20px; }
        .result { margin: 10px 0; padding: 10px; background: #f0f0f0; }
    </style>
</head>
<body>
<h1>🔍 File Search Tool</h1>
<form method="get">
    <input type="text" name="zoek" value="<?php echo htmlspecialchars($zoekterm); ?>" 
           placeholder="Zoek naar bestanden..." size="40">
    <button type="submit">Zoeken</button>
</form>

<?php if (!empty($zoekterm)): ?>
    <h2>Resultaten voor: "<?php echo htmlspecialchars($zoekterm); ?>"</h2>
    <?php if (count($resultaten) > 0): ?>
        <p><?php echo count($resultaten); ?> bestanden gevonden:</p>
        <?php foreach ($resultaten as $resultaat): ?>
            <div class="result">
                <strong>📄 <?php echo htmlspecialchars($resultaat['naam']); ?></strong><br>
                📂 Pad: <?php echo htmlspecialchars($resultaat['pad']); ?><br>
                💾 Grootte: <?php echo round($resultaat['grootte']/1024, 2); ?> KB<br>
                📅 Gewijzigd: <?php echo date('d-m-Y H:i:s', $resultaat['datum']); ?>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>❌ Geen bestanden gevonden met "<?php echo htmlspecialchars($zoekterm); ?>"</p>
    <?php endif; ?>
<?php endif; ?>
</body>
</html>