<?php
// batch_rename.php
$directory = isset($_GET['dir']) ? $_GET['dir'] : './';
$melding = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nieuwe_namen'])) {
    $aantalHernoemd = 0;
    foreach ($_POST['nieuwe_namen'] as $oudPad => $nieuweNaam) {
        $oudPad = base64_decode($oudPad);
        $directory = dirname($oudPad) . '/';
        $nieuwPad = $directory . $nieuweNaam;
        
        if (!empty($nieuweNaam) && $oudPad !== $nieuwPad && rename($oudPad, $nieuwPad)) {
            $aantalHernoemd++;
        }
    }
    $melding = "<div style='color:green;'>✅ {$aantalHernoemd} bestanden hernoemd</div>";
}

// Bestanden ophalen
$bestanden = glob($directory . '*.{txt,php,html,css,js,md}', GLOB_BRACE);
?>
<!DOCTYPE html>
<html>
<head>
    <title>✏️ Batch Rename Tool</title>
    <style>
        table { width: 100%; border-collapse: collapse; }
        td, th { border: 1px solid #ddd; padding: 8px; }
        th { background: #2196F3; color: white; }
    </style>
</head>
<body>
<h1>✏️ Batch Bestands Hernoemer</h1>
<?php echo $melding; ?>

<form method="post">
    <table>
        <thead>
            <tr><th>Huidige naam</th><th>Nieuwe naam</th><th>Extensie</th></tr>
        </thead>
        <tbody>
        <?php foreach ($bestanden as $bestand): ?>
            <?php $info = pathinfo($bestand); ?>
            <tr>
                <td><?php echo htmlspecialchars(basename($bestand)); ?></td>
                <td>
                    <input type="text" name="nieuwe_namen[<?php echo base64_encode($bestand); ?>]" 
                           value="<?php echo htmlspecialchars($info['filename']); ?>">
                    .<?php echo $info['extension']; ?>
                </td>
                <td><?php echo $info['extension']; ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <br>
    <button type="submit">Alle hernoemen</button>
    <button type="button" onclick="location.reload()">Reset</button>
</form>
</body>
</html>