<?php
$directory = './';
$bestand = $_GET['file'] ?? null;

if ($bestand && file_exists($directory . '/' . $bestand)) {
    $inhoud = file_get_contents($directory . '/' . $bestand);
    $woorden = str_word_count(strtolower($inhoud), 1);
    $frequentie = array_count_values($woorden);
    arsort($frequentie);
    $topWoorden = array_slice($frequentie, 0, 30);
} else {
    // Toon bestandskeuze
    $files = glob($directory . '*.txt');
    echo "<h2>Kies een tekstbestand voor woordfrequentie heatmap:</h2><ul>";
    foreach ($files as $f) {
        echo "<li><a href='?file=" . basename($f) . "'>" . basename($f) . "</a></li>";
    }
    echo "</ul>";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        .heatmap {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(100px, auto));
            gap: 5px;
            padding: 20px;
        }
        .word-card {
            padding: 10px;
            text-align: center;
            border-radius: 8px;
            transition: transform 0.2s;
            cursor: pointer;
        }
        .word-card:hover {
            transform: scale(1.05);
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }
        .word {
            font-weight: bold;
        }
        .count {
            font-size: 11px;
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <h2>🔥 Woordfrequentie Heatmap - <?= htmlspecialchars($bestand) ?></h2>
    <p>Totaal verschillende woorden: <?= count($frequentie) ?> | Totaal woordtelling: <?= array_sum($frequentie) ?></p>
    
    <div class="heatmap">
        <?php
        $maxCount = max($topWoorden);
        foreach ($topWoorden as $woord => $count):
            $intensity = ($count / $maxCount) * 255;
            $color = "rgb(255, " . (255 - $intensity) . ", " . (255 - $intensity) . ")";
        ?>
        <div class="word-card" style="background-color: <?= $color ?>;" title="'<?= $woord ?>' komt <?= $count ?> keer voor">
            <div class="word"><?= htmlspecialchars($woord) ?></div>
            <div class="count"><?= $count ?>x</div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <div style="margin-top: 30px;">
        <h3>📊 Top 10 meest voorkomende woorden:</h3>
        <table border="1" cellpadding="8">
            <?php foreach (array_slice($topWoorden, 0, 10) as $woord => $count): ?>
            <tr>
                <td><strong><?= htmlspecialchars($woord) ?></strong></td>
                <td><?= $count ?> keer</td>
                <td><?= str_repeat('█', round($count / $maxCount * 50)) ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>