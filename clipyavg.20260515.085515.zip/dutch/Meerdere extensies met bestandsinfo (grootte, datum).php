<?php
$directory = './';
$toegestaneExtensies = ['txt', 'php', 'html', 'css', 'js'];

$files = array_diff(scandir($directory), ['.', '..']);

echo '<table border="1" cellpadding="5">';
echo '<tr><th>Bestand</th><th>Extensie</th><th>Grootte (bytes)</th><th>Laatste wijziging</th></tr>';

foreach ($files as $file) {
    $path = $directory . '/' . $file;
    
    if (is_file($path)) {
        $extensie = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($extensie, $toegestaneExtensies)) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($file) . '</td>';
            echo '<td>' . $extensie . '</td>';
            echo '<td>' . number_format(filesize($path)) . '</td>';
            echo '<td>' . date('Y-m-d H:i:s', filemtime($path)) . '</td>';
            echo '</tr>';
        }
    }
}

echo '</table>';
?>