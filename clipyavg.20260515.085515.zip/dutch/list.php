<?php
$directory = './';
$files = array_diff(scandir($directory), ['.', '..']);

foreach ($files as $file) {
    $path = $directory . '/' . $file;
    echo $file . '  ' . '<br>' . "\n"; // HTML line breaks
}
?>