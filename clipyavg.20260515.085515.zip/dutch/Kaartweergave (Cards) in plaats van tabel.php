<?php
$directory = './';
$toegestaneExtensies = ['txt', 'php', 'html', 'css', 'js', 'log', 'md'];

$files = array_diff(scandir($directory), ['.', '..']);
$extensieStats = [];
$groottes = [];
$bestandenLijst = [];

foreach ($files as $file) {
    $path = $directory . '/' . $file;
    if (is_file($path)) {
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($ext, $toegestaneExtensies)) {
            $size = filesize($path);
            $extensieStats[$ext] = ($extensieStats[$ext] ?? 0) + 1;
            $groottes[$ext] = ($groottes[$ext] ?? 0) + $size;
            $bestandenLijst[] = [
                'naam' => $file,
                'ext' => $ext,
                'size' => $size,
                'datum' => filemtime($path)
            ];
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .dashboard {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            padding: 20px;
        }
        .chart-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        canvas { max-height: 300px; }
        @media (max-width: 768px) {
            .dashboard { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="chart-card">
            <h3>📊 Aantal bestanden per extensie</h3>
            <canvas id="countChart"></canvas>
        </div>
        <div class="chart-card">
            <h3>💾 Totale grootte per extensie (bytes)</h3>
            <canvas id="sizeChart"></canvas>
        </div>
    </div>
    
    <div class="chart-card" style="margin: 20px;">
        <h3>📅 Bestanden per dag (laatste 7 dagen)</h3>
        <canvas id="timelineChart" style="max-height: 300px;"></canvas>
    </div>

    <script>
        // Aantal bestanden per extensie
        new Chart(document.getElementById('countChart'), {
            type: 'bar',
            data: {
                labels: <?= json_encode(array_keys($extensieStats)) ?>,
                datasets: [{
                    label: 'Aantal bestanden',
                    data: <?= json_encode(array_values($extensieStats)) ?>,
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            }
        });
        
        // Grootte per extensie
        new Chart(document.getElementById('sizeChart'), {
            type: 'pie',
            data: {
                labels: <?= json_encode(array_keys($groottes)) ?>,
                datasets: [{
                    data: <?= json_encode(array_values($groottes)) ?>,
                    backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40']
                }]
            }
        });
        
        // Tijdlijn (laatste 7 dagen)
        const dates = [];
        for (let i = 6; i >= 0; i--) {
            let d = new Date();
            d.setDate(d.getDate() - i);
            dates.push(d.toISOString().split('T')[0]);
        }
        
        new Chart(document.getElementById('timelineChart'), {
            type: 'line',
            data: {
                labels: dates,
                datasets: [{
                    label: 'Bestanden gewijzigd',
                    data: dates.map(date => {
                        return <?= json_encode(array_map(function($b) {
                            return date('Y-m-d', $b['datum']);
                        }, $bestandenLijst)) ?>.filter(d => d === date).length;
                    }),
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1,
                    fill: true,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)'
                }]
            }
        });
    </script>
</body>
</html>