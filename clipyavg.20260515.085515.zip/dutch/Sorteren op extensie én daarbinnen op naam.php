<?php
$directory = './';
$toegestaneExtensies = ['txt', 'php', 'html', 'css', 'js', 'log'];

$files = array_diff(scandir($directory), ['.', '..']);

$bestandInfo = [];

foreach ($files as $file) {
    $path = $directory . '/' . $file;
    
    if (is_file($path)) {
        $extensie = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($extensie, $toegestaneExtensies)) {
            $bestandInfo[] = [
                'naam' => $file,
                'extensie' => $extensie,
                'grootte' => filesize($path),
                'datum' => filemtime($path)
            ];
        }
    }
}

// Sorteren: eerst op extensie, dan op bestandsnaam
usort($bestandInfo, function($a, $b) {
    if ($a['extensie'] == $b['extensie']) {
        return strcmp($a['naam'], $b['naam']);
    }
    return strcmp($a['extensie'], $b['extensie']);
});

// Tabel met kleur per extensie
echo '<table border="1" cellpadding="5" cellspacing="0">';
echo '<tr><th>Bestand</th><th>Extensie</th><th>Grootte</th><th>Datum</th></tr>';

$huidigeExtensie = '';
foreach ($bestandInfo as $info) {
    $bgColor = ($huidigeExtensie != $info['extensie']) ? '#f0f0f0' : 'transparent';
    $huidigeExtensie = $info['extensie'];
    
    echo '<tr style="background-color: ' . $bgColor . ';">';
    echo '<td>' . htmlspecialchars($info['naam']) . '</td>';
    echo '<td><strong>.' . $info['extensie'] . '</strong></td>';
    echo '<td>' . number_format($info['grootte']) . ' bytes</td>';
    echo '<td>' . date('Y-m-d H:i:s', $info['datum']) . '</td>';
    echo '</tr>';
}

echo '</table>';
?>