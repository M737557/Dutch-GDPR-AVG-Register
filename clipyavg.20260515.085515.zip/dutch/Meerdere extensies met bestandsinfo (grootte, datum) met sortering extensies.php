<?php
$directory = './';
$toegestaneExtensies = ['txt', 'php', 'html', 'css', 'js'];

$files = array_diff(scandir($directory), ['.', '..']);

// Verzamel bestandsinfo in array
$bestandInfo = [];

foreach ($files as $file) {
    $path = $directory . '/' . $file;
    
    if (is_file($path)) {
        $extensie = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($extensie, $toegestaneExtensies)) {
            $bestandInfo[] = [
                'naam' => $file,
                'extensie' => $extensie,
                'grootte' => filesize($path),
                'datum' => filemtime($path),
                'pad' => $path
            ];
        }
    }
}

// Sorteren op extensie (alfabetisch)
usort($bestandInfo, function($a, $b) {
    return strcmp($a['extensie'], $b['extensie']);
});

// Weergeven in tabel
echo '<table border="1" cellpadding="5" cellspacing="0">';
echo '<tr style="background-color: #4CAF50; color: white;">';
echo '<th>Bestand</th><th>Extensie</th><th>Grootte (bytes)</th><th>Laatste wijziging</th>';
echo '</tr>';

foreach ($bestandInfo as $info) {
    $datum = date('Y-m-d H:i:s', $info['datum']);
    $grootte = number_format($info['grootte']);
    
    echo '<tr>';
    echo '<td>' . htmlspecialchars($info['naam']) . '</td>';
    echo '<td><strong>.' . $info['extensie'] . '</strong></td>';
    echo '<td>' . $grootte . '</td>';
    echo '<td>' . $datum . '</td>';
    echo '</tr>';
}

echo '</table>';
echo '<p><strong>Totaal:</strong> ' . count($bestandInfo) . ' bestanden gevonden</p>';
?>