<?php
// file_manager.php
$directory = isset($_GET['dir']) ? $_GET['dir'] : './';
$directory = str_replace(['..', '//'], '', $directory); // Beveiliging
$directory = rtrim($directory, '/') . '/';

if (!is_readable($directory)) {
    die('<p style="color:red;">❌ Map niet leesbaar: ' . htmlspecialchars($directory) . '</p>');
}

$toegestaneExtensies = ['txt', 'php', 'html', 'css', 'js', 'md', 'json', 'xml', 'csv', 'log', 'ini', 'conf'];

// Sorteer instellingen
$sorteerOp = $_GET['sorteer'] ?? 'naam';
$volgorde = $_GET['volgorde'] ?? 'oplopend';

// Bestanden ophalen
$files = scandir($directory);
$bestandInfo = [];

foreach ($files as $file) {
    if ($file === '.' || $file === '..') continue;
    
    $path = $directory . $file;
    $extensie = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    
    if (is_file($path) && in_array($extensie, $toegestaneExtensies)) {
        $bestandInfo[] = [
            'naam' => $file,
            'extensie' => $extensie,
            'grootte' => filesize($path),
            'datum' => filemtime($path),
            'pad' => $path,
            'leesbaar' => is_readable($path),
            'schrijfbaar' => is_writable($path)
        ];
    }
}

// Sorteer functie
usort($bestandInfo, function($a, $b) use ($sorteerOp, $volgorde) {
    $result = 0;
    switch ($sorteerOp) {
        case 'naam': $result = strcmp($a['naam'], $b['naam']); break;
        case 'extensie': $result = strcmp($a['extensie'], $b['extensie']); break;
        case 'grootte': $result = $a['grootte'] - $b['grootte']; break;
        case 'datum': $result = $a['datum'] - $b['datum']; break;
    }
    return $volgorde === 'oplopend' ? $result : -$result;
});

// Helpers
function formatteerGrootte($bytes) {
    $eenheden = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    while ($bytes >= 1024 && $i < 3) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, 1) . ' ' . $eenheden[$i];
}

// File acties
$melding = '';
if (isset($_GET['actie']) && isset($_GET['bestand'])) {
    $bestand = basename($_GET['bestand']);
    $pad = $directory . $bestand;
    
    switch ($_GET['actie']) {
        case 'verwijder':
            if (unlink($pad)) {
                $melding = "✅ Bestand '{$bestand}' verwijderd";
                header('Refresh:2');
            } else {
                $melding = "❌ Kan bestand niet verwijderen";
            }
            break;
        case 'bekijk':
            if (is_readable($pad)) {
                $inhoud = htmlspecialchars(file_get_contents($pad));
                echo "<div style='position:fixed;top:20%;left:20%;background:white;border:2px solid #333;padding:20px;max-width:60%;max-height:60%;overflow:auto;z-index:1000;'>
                        <h3>📄 {$bestand}</h3>
                        <pre>{$inhoud}</pre>
                        <button onclick='this.parentElement.style.display=\"none\"'>Sluiten</button>
                      </div>";
            }
            break;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>📁 File Manager</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #4CAF50; color: white; cursor: pointer; }
        tr:hover { background: #f5f5f5; }
        .actie-link { margin: 0 5px; text-decoration: none; }
        .bekijk { color: blue; }
        .wis { color: red; }
        .download { color: green; }
    </style>
</head>
<body>
<h1>📁 File Manager</h1>
<?php if ($melding) echo "<p>{$melding}</p>"; ?>

<form method="get" style="margin-bottom: 20px;">
    <label>📂 Map: </label>
    <input type="text" name="dir" value="<?php echo htmlspecialchars($directory); ?>" style="width:300px;">
    <label>📊 Sorteer: </label>
    <select name="sorteer">
        <option value="naam" <?php echo $sorteerOp=='naam'?'selected':''; ?>>Naam</option>
        <option value="extensie" <?php echo $sorteerOp=='extensie'?'selected':''; ?>>Extensie</option>
        <option value="grootte" <?php echo $sorteerOp=='grootte'?'selected':''; ?>>Grootte</option>
        <option value="datum" <?php echo $sorteerOp=='datum'?'selected':''; ?>>Datum</option>
    </select>
    <select name="volgorde">
        <option value="oplopend" <?php echo $volgorde=='oplopend'?'selected':''; ?>>Oplopend</option>
        <option value="aflopend" <?php echo $volgorde=='aflopend'?'selected':''; ?>>Aflopend</option>
    </select>
    <button type="submit">Toepassen</button>
</form>

<?php if (count($bestandInfo) > 0): ?>
    <table>
        <thead>
            <tr><th>📄 Bestand</th><th>🔧 Extensie</th><th>💾 Grootte</th><th>📅 Laatst gewijzigd</th><th>⚡ Acties</th></tr>
        </thead>
        <tbody>
        <?php foreach ($bestandInfo as $info): ?>
            <tr>
                <td><?php echo htmlspecialchars($info['naam']); ?></td>
                <td><?php echo $info['extensie']; ?></td>
                <td><?php echo formatteerGrootte($info['grootte']); ?></td>
                <td><?php echo date('d-m-Y H:i:s', $info['datum']); ?></td>
                <td>
                    <a href="?bekijk&bestand=<?php echo urlencode($info['naam']); ?>" class="actie-link bekijk">👁️ Bekijk</a>
                    <a href="<?php echo htmlspecialchars($info['pad']); ?>" download class="actie-link download">⬇️ Download</a>
                    <a href="?actie=verwijder&bestand=<?php echo urlencode($info['naam']); ?>" onclick="return confirm('Weet je zeker dat je dit bestand wilt verwijderen?')" class="actie-link wis">❌ Verwijder</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <p><strong>Totaal:</strong> <?php echo count($bestandInfo); ?> bestanden</p>
<?php else: ?>
    <p>📭 Geen bestanden gevonden in deze map</p>
<?php endif; ?>
</body>
</html>