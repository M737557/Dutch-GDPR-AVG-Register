<?php
function buildTree($dir, $extensions = []) {
    $tree = [];
    $items = scandir($dir);
    
    foreach ($items as $item) {
        if ($item == '.' || $item == '..') continue;
        
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        $ext = strtolower(pathinfo($item, PATHINFO_EXTENSION));
        
        if (is_dir($path)) {
            $tree[$item] = buildTree($path, $extensions);
        } elseif (empty($extensions) || in_array($ext, $extensions)) {
            $tree[$item] = null;
        }
    }
    
    return $tree;
}

$directory = '.';
$allowedExt = ['txt', 'php', 'html', 'css', 'js', 'md'];
$tree = buildTree($directory, $allowedExt);
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        .tree {
            font-family: 'Courier New', monospace;
            padding: 20px;
            background: #1e1e1e;
            color: #d4d4d4;
            border-radius: 10px;
        }
        .tree ul {
            list-style: none;
            padding-left: 20px;
        }
        .tree li {
            margin: 5px 0;
            cursor: pointer;
            position: relative;
        }
        .tree li::before {
            content: "📁 ";
        }
        .tree li.file::before {
            content: "📄 ";
        }
        .tree li.php::before { content: "🐘 "; }
        .tree li.html::before { content: "🌐 "; }
        .tree li.css::before { content: "🎨 "; }
        .tree li.js::before { content: "📜 "; }
        .tree li.txt::before { content: "📝 "; }
        
        .tree .folder {
            font-weight: bold;
            color: #4ec9b0;
        }
        .tree .file-item {
            color: #ce9178;
        }
        .tree .hidden {
            display: none;
        }
        .tree .toggle {
            position: absolute;
            left: -15px;
            cursor: pointer;
            user-select: none;
        }
    </style>
</head>
<body>
    <div class="tree">
        <div onclick="toggleFolder(this)">📁 root</div>
        <div id="treeContent">
            <?php function renderTree($tree, $level = 0) {
                foreach ($tree as $name => $children) {
                    $ext = pathinfo($name, PATHINFO_EXTENSION);
                    $class = is_array($children) ? 'folder' : 'file-item ' . $ext;
                    echo '<div style="margin-left: ' . ($level * 20) . 'px">';
                    
                    if (is_array($children) && !empty($children)) {
                        echo '<span class="toggle" onclick="toggleFolder(this)">▼</span> ';
                        echo '<span class="' . $class . '">' . htmlspecialchars($name) . '</span>';
                        echo '<div class="folder-content">';
                        renderTree($children, $level + 1);
                        echo '</div>';
                    } elseif (is_array($children)) {
                        echo '<span style="margin-left: 15px"></span> ';
                        echo '<span class="' . $class . '">' . htmlspecialchars($name) . '</span>';
                        echo '<div class="folder-content hidden"></div>';
                    } else {
                        echo '<span class="toggle"></span> ';
                        echo '<span class="' . $class . '">' . htmlspecialchars($name) . '</span>';
                    }
                    
                    echo '</div>';
                }
            }
            renderTree($tree); ?>
        </div>
    </div>
    
    <script>
        function toggleFolder(element) {
            let content = element.nextElementSibling.nextElementSibling;
            if (content && content.classList.contains('folder-content')) {
                content.classList.toggle('hidden');
                element.textContent = content.classList.contains('hidden') ? '▶' : '▼';
            }
        }
        
        // Initialize all toggles
        document.querySelectorAll('.toggle').forEach(toggle => {
            if (toggle.textContent === '▼') {
                let content = toggle.nextElementSibling.nextElementSibling;
                if (content && content.children.length === 0) {
                    toggle.textContent = '';
                }
            }
        });
    </script>
</body>
</html>