<?php
$directory = './';
$bestand = $_GET['file'] ?? '';

if ($bestand && file_exists($bestand)) {
    $text = strtolower(file_get_contents($bestand));
    $words = str_word_count($text, 1);
    $stopwords = ['the', 'and', 'of', 'to', 'in', 'a', 'is', 'for', 'on', 'with', 
                  'by', 'at', 'from', 'are', 'was', 'were', 'be', 'this', 'that'];
    $words = array_filter($words, function($w) use ($stopwords) {
        return strlen($w) > 2 && !in_array($w, $stopwords);
    });
    $freq = array_count_values($words);
    arsort($freq);
    $topWords = array_slice($freq, 0, 100);
    
    // Calculate font sizes
    $maxFreq = max($topWords);
    $minFreq = min($topWords);
} else {
    $files = glob($directory . '*.txt');
}
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        .wordcloud {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            min-height: 500px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 15px;
            padding: 30px;
            margin: 20px;
        }
        .word {
            margin: 10px;
            padding: 5px;
            color: white;
            transition: transform 0.3s, opacity 0.3s;
            cursor: pointer;
            opacity: 0.8;
        }
        .word:hover {
            transform: scale(1.1);
            opacity: 1;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .file-selector {
            text-align: center;
            margin: 20px;
        }
        select, button {
            padding: 10px 20px;
            font-size: 16px;
            margin: 5px;
        }
        .stats {
            text-align: center;
            margin-top: 20px;
            padding: 15px;
            background: #f0f0f0;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <?php if (!$bestand): ?>
    <div class="file-selector">
        <h2>🎨 Kies een bestand voor de Word Cloud</h2>
        <form method="get">
            <select name="file">
                <option value="">Selecteer bestand...</option>
                <?php foreach ($files as $f): ?>
                    <option value="<?= $f ?>"><?= basename($f) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Genereer Word Cloud</button>
        </form>
    </div>
    <?php else: ?>
    <div class="wordcloud" id="wordcloud">
        <?php foreach ($topWords as $word => $count): 
            $size = 12 + (($count - $minFreq) / ($maxFreq - $minFreq)) * 60;
            $rotation = rand(-15, 15);
            $colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#F7DC6F'];
            $color = $colors[array_rand($colors)];
        ?>
        <span class="word" 
              style="font-size: <?= $size ?>px; 
                     transform: rotate(<?= $rotation ?>deg);
                     color: <?= $color ?>;"
              title="'<?= htmlspecialchars($word) ?>' komt <?= $count ?> keer voor">
            <?= htmlspecialchars($word) ?>
        </span>
        <?php endforeach; ?>
    </div>
    
    <div class="stats">
        <h3>📊 Statistieken voor <?= basename($bestand) ?></h3>
        <p>🎯 Unieke woorden: <?= count($freq) ?> | 
           🔥 Meest gebruikt: "<?= array_key_first($topWords) ?>" (<?= $topWords[array_key_first($topWords)] ?>x) |
           📝 Totaal woorden: <?= array_sum($freq) ?></p>
        <a href="?">← Kies ander bestand</a>
    </div>
    <?php endif; ?>
</body>
</html>