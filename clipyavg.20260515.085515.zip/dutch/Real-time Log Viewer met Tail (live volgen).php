<?php
$logFile = $_GET['log'] ?? '';
$lines = $_GET['lines'] ?? 50;
$directory = './';
$logFiles = glob($directory . '*.{log,txt}', GLOB_BRACE);
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        .log-viewer {
            background: #1e1e1e;
            color: #d4d4d4;
            font-family: 'Consolas', 'Courier New', monospace;
            padding: 20px;
            border-radius: 10px;
            overflow-x: auto;
        }
        .log-line {
            padding: 4px 8px;
            border-bottom: 1px solid #333;
            font-size: 13px;
            white-space: pre-wrap;
            word-break: break-all;
        }
        .log-line:hover {
            background: #2d2d2d;
        }
        .line-number {
            display: inline-block;
            width: 50px;
            color: #858585;
            user-select: none;
            margin-right: 15px;
            text-align: right;
        }
        .log-level-ERROR { color: #f48771; }
        .log-level-WARNING { color: #dcdcaa; }
        .log-level-INFO { color: #4ec9b0; }
        .log-level-DEBUG { color: #9cdcfe; }
        .controls {
            margin-bottom: 20px;
            padding: 15px;
            background: #f0f0f0;
            border-radius: 10px;
        }
        .status {
            padding: 8px;
            margin-top: 10px;
            background: #2d2d2d;
            border-radius: 5px;
            font-size: 12px;
        }
        .live-badge {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #ff4444;
            animation: pulse 1s infinite;
            margin-right: 8px;
        }
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.3; }
            100% { opacity: 1; }
        }
        .highlight {
            background-color: #ffff00;
            color: #000;
        }
    </style>
</head>
<body>
    <div class="controls">
        <form method="get" style="display: inline;">
            <select name="log" onchange="this.form.submit()">
                <option value="">Selecteer logbestand...</option>
                <?php foreach ($logFiles as $f): ?>
                    <option value="<?= basename($f) ?>" <?= $logFile == basename($f) ? 'selected' : '' ?>>
                        <?= basename($f) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            
            <select name="lines" onchange="this.form.submit()">
                <option value="20" <?= $lines == 20 ? 'selected' : '' ?>>20 regels</option>
                <option value="50" <?= $lines == 50 ? 'selected' : '' ?>>50 regels</option>
                <option value="100" <?= $lines == 100 ? 'selected' : '' ?>>100 regels</option>
                <option value="500" <?= $lines == 500 ? 'selected' : '' ?>>500 regels</option>
            </select>
            
            <button type="button" onclick="toggleLive()">
                <span id="liveIndicator"></span> Live volgen
            </button>
            
            <input type="text" id="searchInput" placeholder="🔍 Zoeken in log..." onkeyup="searchLog()">
            <button type="button" onclick="exportLog()">📥 Exporteer</button>
        </form>
    </div>
    
    <div class="log-viewer" id="logViewer">
        <?php if ($logFile && file_exists($logFile)): 
            $logLines = file($logFile);
            $totalLines = count($logLines);
            $displayLines = array_slice($logLines, -$lines);
            foreach ($displayLines as $index => $line):
                $lineNum = $totalLines - $lines + $index + 1;
                $level = 'INFO';
                if (stripos($line, 'error') !== false) $level = 'ERROR';
                elseif (stripos($line, 'warning') !== false) $level = 'WARNING';
                elseif (stripos($line, 'debug') !== false) $level = 'DEBUG';
        ?>
        <div class="log-line log-level-<?= $level ?>" data-line="<?= htmlspecialchars($line) ?>">
            <span class="line-number"><?= $lineNum ?></span>
            <?= htmlspecialchars($line) ?>
        </div>
        <?php endforeach; ?>
        <?php else: ?>
            <p>Selecteer een logbestand om te bekijken</p>
        <?php endif; ?>
    </div>
    
    <div class="status" id="status">
        <?php if ($logFile): ?>
            Bestand: <?= $logFile ?> | 
            Laatste <?= $lines ?> van <?= $totalLines ?> regels | 
            Grootte: <?= number_format(filesize($logFile)) ?> bytes
        <?php endif; ?>
    </div>

    <script>
        let liveMode = false;
        let intervalId = null;
        
        function toggleLive() {
            liveMode = !liveMode;
            const indicator = document.getElementById('liveIndicator');
            if (liveMode) {
                indicator.innerHTML = '<span class="live-badge"></span>';
                startLive();
            } else {
                indicator.innerHTML = '';
                if (intervalId) clearInterval(intervalId);
            }
        }
        
        function startLive() {
            if (intervalId) clearInterval(intervalId);
            intervalId = setInterval(() => {
                fetch(window.location.href + '&ajax=1')
                    .then(response => response.text())
                    .then(html => {
                        const parser = new DOMParser();
                        const doc = parser.parseFromString(html, 'text/html');
                        const newContent = doc.getElementById('logViewer').innerHTML;
                        document.getElementById('logViewer').innerHTML = newContent;
                    });
            }, 3000);
        }
        
        function searchLog() {
            const search = document.getElementById('searchInput').value.toLowerCase();
            const lines = document.querySelectorAll('.log-line');
            
            lines.forEach(line => {
                const text = line.getAttribute('data-line').toLowerCase();
                if (search === '' || text.includes(search)) {
                    line.style.display = '';
                    if (search !== '' && text.includes(search)) {
                        const innerHtml = line.innerHTML;
                        const regex = new RegExp(`(${search})`, 'gi');
                        line.innerHTML = innerHtml.replace(regex, '<span class="highlight">$1</span>');
                    }
                } else {
                    line.style.display = 'none';
                }
            });
        }
        
        function exportLog() {
            window.location.href = '?export=<?= $logFile ?>';
        }
    </script>
    
    <?php
    // Export functionaliteit
    if (isset($_GET['export']) && file_exists($_GET['export'])) {
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="' . basename($_GET['export']) . '"');
        readfile($_GET['export']);
        exit;
    }
    
    // AJAX endpoint
    if (isset($_GET['ajax'])) {
        $logFile = $_GET['log'] ?? '';
        $lines = $_GET['lines'] ?? 50;
        if ($logFile && file_exists($logFile)) {
            $logLines = file($logFile);
            $displayLines = array_slice($logLines, -$lines);
            foreach ($displayLines as $line) {
                echo htmlspecialchars($line) . "<br>";
            }
        }
        exit;
    }
    ?>
</body>
</html>