<?php
$directory = './';

$files = array_diff(scandir($directory), ['.', '..']);

$extensieTeller = [];

foreach ($files as $file) {
    $path = $directory . '/' . $file;
    
    if (is_file($path)) {
        $extensie = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if ($extensie === '') $extensie = '[geen extensie]';
        
        if (!isset($extensieTeller[$extensie])) {
            $extensieTeller[$extensie] = [];
        }
        $extensieTeller[$extensie][] = $file;
    }
}

// Toon per extensie
foreach ($extensieTeller as $extensie => $bestanden) {
    echo "<strong>.{$extensie}</strong> (" . count($bestanden) . " bestanden)<br>";
    foreach ($bestanden as $bestand) {
        echo "&nbsp;&nbsp;&nbsp; - " . htmlspecialchars($bestand) . "<br>";
    }
    echo "<br>";
}
?>