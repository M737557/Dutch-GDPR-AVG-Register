<?php
// ============================================
// PROFESSIONELE BESTANDENZOEKER - BUSINESS EDITION
// MET RESPONSIVE TABEL & FIXE KOLOMBREEDTES
// ============================================

// Configuratie (zelfde als eerder)
$baseDirectory = isset($_POST['directory']) ? $_POST['directory'] : (isset($_GET['dir']) ? $_GET['dir'] : getcwd());
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';
$fileTypes = isset($_GET['types']) && !empty($_GET['types']) ? explode(',', $_GET['types']) : ['txt', 'php', 'html', 'css', 'js', 'log', 'md', 'json', 'xml', 'csv', 'pdf', 'doc', 'docx'];
$dateFilter = isset($_GET['date_filter']) ? $_GET['date_filter'] : 'all';
$dateFrom = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$dateTo = isset($_GET['date_to']) ? $_GET['date_to'] : '';
$sortBy = isset($_GET['sort']) ? $_GET['sort'] : 'modified';
$sortOrder = isset($_GET['order']) ? $_GET['order'] : 'desc';
$minSize = isset($_GET['min_size']) ? (int)$_GET['min_size'] : 0;
$maxSize = isset($_GET['max_size']) ? (int)$_GET['max_size'] : 0;
$recursive = !isset($_GET['recursive']) || $_GET['recursive'] == 'on' || $_GET['recursive'] == '1' || $_GET['recursive'] === 'true';
$showHidden = isset($_GET['show_hidden']) ? true : false;

// Veiligheid: base directory valideren
$baseDirectory = realpath($baseDirectory);
if (!$baseDirectory || !is_dir($baseDirectory)) {
    $baseDirectory = getcwd();
}

// Resultaten opslaan
$results = [];

// Scan functie (zelfde als eerder)
function scanDirectory($dir, $searchTerm, $fileTypes, $recursive, $baseDir, $showHidden) {
    global $results, $minSize, $maxSize;
    
    if (!is_readable($dir)) return;
    
    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item == '.' || $item == '..') continue;
        if (!$showHidden && substr($item, 0, 1) == '.') continue;
        
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        $relativePath = str_replace($baseDir . DIRECTORY_SEPARATOR, '', $path);
        
        if (is_dir($path)) {
            if ($recursive) {
                scanDirectory($path, $searchTerm, $fileTypes, $recursive, $baseDir, $showHidden);
            }
        } else {
            $ext = strtolower(pathinfo($item, PATHINFO_EXTENSION));
            
            if (!empty($fileTypes) && !in_array($ext, $fileTypes)) continue;
            
            $size = filesize($path);
            if ($minSize > 0 && $size < $minSize) continue;
            if ($maxSize > 0 && $size > $maxSize) continue;
            
            $match = empty($searchTerm) || stripos($item, $searchTerm) !== false;
            
            if ($match) {
                $stat = stat($path);
                $results[] = [
                    'name' => $item,
                    'path' => $path,
                    'relative_path' => $relativePath,
                    'ext' => $ext,
                    'size' => $size,
                    'size_kb' => round($size / 1024, 2),
                    'size_mb' => round($size / (1024 * 1024), 2),
                    'created' => $stat['ctime'],
                    'modified' => $stat['mtime'],
                    'accessed' => $stat['atime'],
                    'created_str' => date('Y-m-d H:i:s', $stat['ctime']),
                    'modified_str' => date('Y-m-d H:i:s', $stat['mtime']),
                    'accessed_str' => date('Y-m-d H:i:s', $stat['atime']),
                ];
            }
        }
    }
}

// Filter en sorteer (zelfde als eerder)
function filterByDate($results, $filter, $dateFrom, $dateTo) {
    $now = time();
    $today = strtotime(date('Y-m-d 00:00:00'));
    $yesterday = strtotime('-1 day', $today);
    $weekAgo = strtotime('-7 days', $today);
    $monthAgo = strtotime('-30 days', $today);
    
    return array_filter($results, function($file) use ($filter, $dateFrom, $dateTo, $now, $today, $yesterday, $weekAgo, $monthAgo) {
        $modified = $file['modified'];
        
        switch ($filter) {
            case 'today': return $modified >= $today;
            case 'yesterday': return $modified >= $yesterday && $modified < $today;
            case 'week': return $modified >= $weekAgo;
            case 'month': return $modified >= $monthAgo;
            case 'custom':
                $from = $dateFrom ? strtotime($dateFrom . ' 00:00:00') : 0;
                $to = $dateTo ? strtotime($dateTo . ' 23:59:59') : $now;
                return $modified >= $from && $modified <= $to;
            default: return true;
        }
    });
}

function sortResults($results, $sortBy, $sortOrder) {
    usort($results, function($a, $b) use ($sortBy, $sortOrder) {
        $result = 0;
        switch ($sortBy) {
            case 'name': $result = strcasecmp($a['name'], $b['name']); break;
            case 'size': $result = $a['size'] - $b['size']; break;
            case 'created': $result = $a['created'] - $b['created']; break;
            case 'accessed': $result = $a['accessed'] - $b['accessed']; break;
            default: $result = $a['modified'] - $b['modified']; break;
        }
        return $sortOrder == 'asc' ? $result : -$result;
    });
    return $results;
}

// Start scanning
scanDirectory($baseDirectory, $searchTerm, $fileTypes, $recursive, $baseDirectory, $showHidden);
$results = filterByDate($results, $dateFilter, $dateFrom, $dateTo);
$results = sortResults($results, $sortBy, $sortOrder);

$totalSize = array_sum(array_column($results, 'size'));
$totalFiles = count($results);
$extensions = array_count_values(array_column($results, 'ext'));
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>Business File Explorer | Professional Document Management</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f5f5f5;
            color: #1a1a1a;
            line-height: 1.5;
        }
        
        .app-container {
            max-width: 100%;
            margin: 0 auto;
            padding: 20px;
        }
        
        .app-header {
            background: #1a1a1a;
            color: #ffffff;
            padding: 30px 40px;
            margin-bottom: 30px;
            border-radius: 4px;
        }
        
        .app-header h1 {
            font-size: 24px;
            font-weight: 500;
            margin-bottom: 8px;
        }
        
        .app-header p {
            font-size: 14px;
            color: #999;
        }
        
        .info-banner {
            background: #f0f0f0;
            border-left: 3px solid #1a1a1a;
            padding: 12px 16px;
            margin-bottom: 20px;
            font-size: 12px;
        }
        
        .main-layout {
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
        }
        
        .sidebar {
            width: 320px;
            flex-shrink: 0;
        }
        
        .content {
            flex: 1;
            min-width: 0;
            overflow-x: auto;
        }
        
        .card {
            background: #ffffff;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            margin-bottom: 20px;
            overflow: hidden;
        }
        
        .card-header {
            background: #fafafa;
            padding: 16px 20px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .card-header h2 {
            font-size: 16px;
            font-weight: 600;
            color: #1a1a1a;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        /* Directory Tree */
        .directory-tree {
            font-size: 13px;
        }
        
        .tree-item {
            margin: 4px 0;
        }
        
        .tree-item-dir {
            cursor: pointer;
            padding: 8px 12px;
            border-radius: 3px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .tree-item-dir:hover {
            background: #f0f0f0;
        }
        
        .tree-children {
            margin-left: 24px;
            display: none;
        }
        
        .tree-children.open {
            display: block;
        }
        
        .current-directory {
            background: #fafafa;
            padding: 12px;
            margin-bottom: 16px;
            border-radius: 4px;
            font-family: monospace;
            font-size: 12px;
            word-break: break-all;
            border: 1px solid #e0e0e0;
        }
        
        /* Form Elements */
        .form-group {
            margin-bottom: 16px;
        }
        
        .form-group label {
            display: block;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #666;
            margin-bottom: 6px;
        }
        
        .form-control {
            width: 100%;
            padding: 10px 12px;
            font-size: 13px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #333;
        }
        
        .form-row {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .form-row .form-group {
            flex: 1;
            min-width: 120px;
        }
        
        .checkbox {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }
        
        .btn {
            padding: 10px 20px;
            font-size: 13px;
            font-weight: 500;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        
        .btn-primary {
            background: #1a1a1a;
            color: #ffffff;
        }
        
        .btn-primary:hover {
            background: #333;
        }
        
        .btn-secondary {
            background: #f0f0f0;
            color: #333;
            border: 1px solid #ccc;
        }
        
        .btn-group {
            display: flex;
            gap: 10px;
            margin-top: 16px;
            flex-wrap: wrap;
        }
        
        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .stat-card {
            background: #ffffff;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            padding: 16px 20px;
            text-align: center;
        }
        
        .stat-number {
            font-size: 28px;
            font-weight: 600;
            color: #1a1a1a;
        }
        
        .stat-label {
            font-size: 11px;
            text-transform: uppercase;
            color: #888;
            margin-top: 6px;
        }
        
        /* ============================================
           RESPONSIVE TABLE - FIXE KOLOMBREEDTES
           ============================================ */
        
        .table-container {
            overflow-x: auto;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            background: #fff;
            margin-bottom: 20px;
        }
        
        /* Gebruik table-layout: fixed voor controleerbare breedtes */
        .file-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            font-size: 12px;
            min-width: 900px;
        }
        
        /* Specifieke kolombreedtes */
        .file-table th:nth-child(1),
        .file-table td:nth-child(1) {
            width: 35%;
            min-width: 200px;
        }
        
        .file-table th:nth-child(2),
        .file-table td:nth-child(2) {
            width: 8%;
            min-width: 70px;
        }
        
        .file-table th:nth-child(3),
        .file-table td:nth-child(3) {
            width: 12%;
            min-width: 90px;
        }
        
        .file-table th:nth-child(4),
        .file-table td:nth-child(4) {
            width: 17%;
            min-width: 130px;
        }
        
        .file-table th:nth-child(5),
        .file-table td:nth-child(5) {
            width: 17%;
            min-width: 130px;
        }
        
        .file-table th:nth-child(6),
        .file-table td:nth-child(6) {
            width: 11%;
            min-width: 100px;
        }
        
        .file-table th {
            text-align: left;
            padding: 12px 12px;
            background: #fafafa;
            border-bottom: 1px solid #e0e0e0;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 11px;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }
        
        .file-table th a {
            color: #333;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        .file-table td {
            padding: 10px 12px;
            border-bottom: 1px solid #f0f0f0;
            vertical-align: top;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }
        
        .file-table tr:hover {
            background: #fafafa;
        }
        
        /* Bestand kolom met truncatie */
        .file-name-cell {
            font-family: 'Courier New', monospace;
            font-size: 12px;
        }
        
        .file-name {
            font-weight: 500;
            word-break: break-word;
        }
        
        .file-path {
            font-size: 10px;
            color: #888;
            margin-top: 4px;
            word-break: break-all;
        }
        
        /* Truncate voor lange bestandsnamen */
        .file-name-truncate {
            display: block;
            max-width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        .file-name-truncate:hover {
            white-space: normal;
            word-break: break-word;
            background: #fff;
            position: relative;
            z-index: 1;
        }
        
        .badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 3px;
            font-size: 10px;
            font-weight: 600;
            text-transform: uppercase;
            background: #f0f0f0;
            color: #333;
        }
        
        .size-bar {
            width: 100%;
            max-width: 80px;
            height: 3px;
            background: #e0e0e0;
            border-radius: 2px;
            overflow: hidden;
            margin-top: 5px;
        }
        
        .size-fill {
            height: 100%;
            background: #333;
            border-radius: 2px;
        }
        
        .action-buttons {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }
        
        .action-btn {
            padding: 4px 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
            font-size: 10px;
            cursor: pointer;
            background: #fff;
            color: #333;
            text-decoration: none;
            display: inline-block;
            white-space: nowrap;
        }
        
        .action-btn:hover {
            background: #f0f0f0;
        }
        
        .results-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            flex-wrap: wrap;
            gap: 12px;
        }
        
        .results-count {
            background: #f0f0f0;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 12px;
        }
        
        .recursive-badge {
            display: inline-block;
            background: #1a1a1a;
            color: white;
            font-size: 10px;
            padding: 2px 8px;
            border-radius: 12px;
            margin-left: 8px;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #888;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background: #fff;
            margin: 5% auto;
            width: 90%;
            max-width: 1000px;
            border-radius: 4px;
        }
        
        .modal-header {
            padding: 16px 20px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .close {
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }
        
        .modal-body {
            padding: 20px;
            max-height: 70vh;
            overflow-y: auto;
        }
        
        .preview-content {
            font-family: 'Courier New', monospace;
            font-size: 12px;
            background: #fafafa;
            padding: 15px;
            border-radius: 3px;
            white-space: pre-wrap;
            word-break: break-all;
            overflow-x: auto;
        }
        
        /* Responsive */
        @media (max-width: 1200px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 768px) {
            .main-layout {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .file-table th,
            .file-table td {
                padding: 8px 8px;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .action-btn {
                text-align: center;
            }
        }
        
        /* Tooltip voor lange bestandsnamen */
        .tooltip {
            position: relative;
            display: inline-block;
            cursor: help;
        }
        
        .tooltip .tooltip-text {
            visibility: hidden;
            background-color: #333;
            color: #fff;
            text-align: left;
            padding: 8px 12px;
            border-radius: 4px;
            position: absolute;
            z-index: 1;
            bottom: 125%;
            left: 0;
            white-space: nowrap;
            font-size: 11px;
            font-family: monospace;
        }
        
        .tooltip:hover .tooltip-text {
            visibility: visible;
        }
    </style>
</head>
<body>
    <div class="app-container">
        <div class="app-header">
            <h1>Business File Explorer</h1>
            <p>Professional document management system | Search, filter, and manage files</p>
        </div>
        
        <div class="info-banner">
            <strong>🔄 RECURSIVE SEARCH ACTIVE</strong> — Alle submappen worden doorzocht. U kunt dit uitzetten via de checkbox.
        </div>
        
        <div class="main-layout">
            <!-- Sidebar -->
            <div class="sidebar">
                <div class="card">
                    <div class="card-header">
                        <h2>📁 DIRECTORY</h2>
                    </div>
                    <div class="card-body">
                        <form method="post" id="dirForm">
                            <div class="form-group">
                                <label>📂 PAD / DIRECTORY</label>
                                <input type="text" name="directory" class="form-control" 
                                       value="<?= htmlspecialchars($baseDirectory) ?>">
                            </div>
                            <div class="btn-group">
                                <button type="submit" class="btn btn-primary" style="flex: 1;">📂 Navigeer</button>
                                <button type="button" class="btn btn-secondary" onclick="browseDirectory()">🔍 Blader</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h2>🔍 ZOEK & FILTERS</h2>
                    </div>
                    <div class="card-body">
                        <form method="get" id="searchForm">
                            <input type="hidden" name="dir" value="<?= htmlspecialchars($baseDirectory) ?>">
                            
                            <div class="form-group">
                                <label>🔎 ZOEKTERM</label>
                                <input type="text" name="search" class="form-control" 
                                       value="<?= htmlspecialchars($searchTerm) ?>" 
                                       placeholder="Bestandsnaam...">
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>📄 TYPEN</label>
                                    <input type="text" name="types" class="form-control" 
                                           value="<?= htmlspecialchars(implode(',', $fileTypes)) ?>">
                                </div>
                                <div class="form-group">
                                    <label>📅 DATUM</label>
                                    <select name="date_filter" class="form-control" id="dateFilter" onchange="toggleCustomDates()">
                                        <option value="all" <?= $dateFilter == 'all' ? 'selected' : '' ?>>Alle</option>
                                        <option value="today" <?= $dateFilter == 'today' ? 'selected' : '' ?>>Vandaag</option>
                                        <option value="yesterday" <?= $dateFilter == 'yesterday' ? 'selected' : '' ?>>Gisteren</option>
                                        <option value="week" <?= $dateFilter == 'week' ? 'selected' : '' ?>>7 dagen</option>
                                        <option value="month" <?= $dateFilter == 'month' ? 'selected' : '' ?>>30 dagen</option>
                                        <option value="custom" <?= $dateFilter == 'custom' ? 'selected' : '' ?>>Aangepast</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="form-row" id="customDates" style="display: <?= $dateFilter == 'custom' ? 'flex' : 'none' ?>;">
                                <div class="form-group">
                                    <label>VANAF</label>
                                    <input type="date" name="date_from" class="form-control" value="<?= $dateFrom ?>">
                                </div>
                                <div class="form-group">
                                    <label>TOT</label>
                                    <input type="date" name="date_to" class="form-control" value="<?= $dateTo ?>">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>📏 MIN (bytes)</label>
                                    <input type="number" name="min_size" class="form-control" value="<?= $minSize ?: '' ?>">
                                </div>
                                <div class="form-group">
                                    <label>📏 MAX (bytes)</label>
                                    <input type="number" name="max_size" class="form-control" value="<?= $maxSize ?: '' ?>">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>📊 SORTEREN</label>
                                    <select name="sort" class="form-control">
                                        <option value="name" <?= $sortBy == 'name' ? 'selected' : '' ?>>Naam</option>
                                        <option value="modified" <?= $sortBy == 'modified' ? 'selected' : '' ?>>Gewijzigd</option>
                                        <option value="created" <?= $sortBy == 'created' ? 'selected' : '' ?>>Aangemaakt</option>
                                        <option value="size" <?= $sortBy == 'size' ? 'selected' : '' ?>>Grootte</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>🔼 VOLGORDE</label>
                                    <select name="order" class="form-control">
                                        <option value="desc" <?= $sortOrder == 'desc' ? 'selected' : '' ?>>Aflopend</option>
                                        <option value="asc" <?= $sortOrder == 'asc' ? 'selected' : '' ?>>Oplopend</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="checkbox">
                                        <input type="checkbox" name="recursive" <?= $recursive ? 'checked' : '' ?>>
                                        <span>📂 Recursief <strong>(standaard aan)</strong></span>
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label class="checkbox">
                                        <input type="checkbox" name="show_hidden" <?= $showHidden ? 'checked' : '' ?>>
                                        <span>👁️ Verborgen</span>
                                    </label>
                                </div>
                            </div>
                            
                            <div class="btn-group">
                                <button type="submit" class="btn btn-primary">🔍 Zoeken</button>
                                <button type="button" class="btn btn-secondary" onclick="resetFilters()">🔄 Reset</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="content">
                <?php if ($totalFiles > 0): ?>
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-number"><?= number_format($totalFiles) ?></div>
                        <div class="stat-label">Bestanden</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?= round($totalSize / (1024 * 1024), 2) ?> MB</div>
                        <div class="stat-label">Totale grootte</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?= count($extensions) ?></div>
                        <div class="stat-label">Extensies</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?= round($totalFiles > 0 ? $totalSize / $totalFiles / 1024 : 0, 1) ?> KB</div>
                        <div class="stat-label">Gem. grootte</div>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="results-header">
                    <div class="results-count">
                        📄 <strong><?= number_format($totalFiles) ?></strong> bestanden
                        <?php if ($searchTerm): ?> voor "<strong><?= htmlspecialchars($searchTerm) ?></strong>"<?php endif; ?>
                        <?php if ($recursive): ?>
                        <span class="recursive-badge">incl. submappen</span>
                        <?php endif; ?>
                    </div>
                    <div class="export-buttons">
                        <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 11px;" onclick="exportToCSV()">📊 CSV</button>
                        <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 11px;" onclick="exportToJSON()">📋 JSON</button>
                    </div>
                </div>
                
                <div class="table-container">
                    <?php if (empty($results)): ?>
                    <div class="empty-state">
                        <div class="icon">📂</div>
                        <h3>Geen bestanden gevonden</h3>
                        <p>Pas uw zoekcriteria aan of navigeer naar een andere directory</p>
                    </div>
                    <?php else: ?>
                    <table class="file-table">
                        <thead>
                            <tr>
                                <th><a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'name', 'order' => $sortBy == 'name' && $sortOrder == 'asc' ? 'desc' : 'asc', 'dir' => $baseDirectory])) ?>">📄 Bestand</a></th>
                                <th>🔖 Type</th>
                                <th><a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'size', 'order' => $sortBy == 'size' && $sortOrder == 'asc' ? 'desc' : 'asc', 'dir' => $baseDirectory])) ?>">💾 Grootte</a></th>
                                <th><a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'created', 'order' => $sortBy == 'created' && $sortOrder == 'asc' ? 'desc' : 'asc', 'dir' => $baseDirectory])) ?>">📅 Aangemaakt</a></th>
                                <th><a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'modified', 'order' => $sortBy == 'modified' && $sortOrder == 'asc' ? 'desc' : 'asc', 'dir' => $baseDirectory])) ?>">🕒 Gewijzigd</a></th>
                                <th>⚡ Acties</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $maxSize = !empty($results) ? max(array_column($results, 'size')) : 1;
                            foreach ($results as $file): 
                                $sizePercent = ($file['size'] / $maxSize) * 100;
                                $displayName = strlen($file['name']) > 50 ? substr($file['name'], 0, 47) . '...' : $file['name'];
                            ?>
                            <tr>
                                <td class="file-name-cell">
                                    <div class="tooltip">
                                        <span class="file-name">
                                            <span class="file-icon"><?= $file['ext'] == 'txt' ? '📝' : ($file['ext'] == 'php' ? '🐘' : ($file['ext'] == 'html' ? '🌐' : '📄')) ?></span>
                                            <span class="file-name-truncate"><?= htmlspecialchars($displayName) ?></span>
                                        </span>
                                        <span class="tooltip-text"><?= htmlspecialchars($file['name']) ?></span>
                                    </div>
                                    <div class="file-path"><?= htmlspecialchars($file['relative_path']) ?></div>
                                 </td>
                                <td><span class="badge"><?= strtoupper($file['ext']) ?></span></td>
                                <td>
                                    <?= $file['size_mb'] >= 1 ? number_format($file['size_mb'], 2) . ' MB' : number_format($file['size_kb'], 1) . ' KB' ?>
                                    <div class="size-bar"><div class="size-fill" style="width: <?= $sizePercent ?>%"></div></div>
                                </td>
                                <td><?= date('d-m-Y H:i', $file['created']) ?></td>
                                <td>
                                    <?= date('d-m-Y H:i', $file['modified']) ?>
                                    <?php $hoursAgo = round((time() - $file['modified']) / 3600, 1); ?>
                                    <?php if ($hoursAgo < 24 && $hoursAgo > 0): ?>
                                        <div style="font-size: 9px; color: #888;">(<?= $hoursAgo ?> uur)</div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="action-btn" onclick="previewFile('<?= addslashes($file['path']) ?>')">👁️ Preview</button>
                                        <a href="?download=<?= urlencode($file['path']) ?>" class="action-btn">⬇️ Download</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal -->
    <div id="previewModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Bestand preview</h3>
                <span class="close" onclick="closeModal()">&times;</span>
            </div>
            <div class="modal-body">
                <div id="previewContent" class="preview-content">Laden...</div>
            </div>
        </div>
    </div>
    
    <script>
        function browseDirectory() {
            const input = document.createElement('input');
            input.type = 'file';
            input.webkitdirectory = true;
            input.onchange = function(e) {
                if (e.target.files.length > 0) {
                    let path = e.target.files[0].webkitRelativePath;
                    path = path.substring(0, path.lastIndexOf('/'));
                    document.querySelector('input[name="directory"]').value = path;
                    document.getElementById('dirForm').submit();
                }
            };
            input.click();
        }
        
        function toggleCustomDates() {
            const filter = document.getElementById('dateFilter').value;
            document.getElementById('customDates').style.display = filter === 'custom' ? 'flex' : 'none';
        }
        
        function resetFilters() {
            window.location.href = window.location.pathname + '?dir=<?= urlencode($baseDirectory) ?>';
        }
        
        function previewFile(path) {
            const modal = document.getElementById('previewModal');
            const previewContent = document.getElementById('previewContent');
            modal.style.display = 'block';
            previewContent.innerHTML = 'Laden...';
            
            fetch('?preview=' + encodeURIComponent(path))
                .then(response => response.text())
                .then(content => {
                    previewContent.innerHTML = '<pre>' + escapeHtml(content) + '</pre>';
                })
                .catch(err => {
                    previewContent.innerHTML = 'Fout: ' + err;
                });
        }
        
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function closeModal() {
            document.getElementById('previewModal').style.display = 'none';
        }
        
        function exportToCSV() {
            let csv = "Bestandsnaam,Pad,Extensie,Grootte (KB),Aangemaakt,Gewijzigd\n";
            <?php foreach ($results as $file): ?>
                csv += `"<?= addslashes($file['name']) ?>","<?= addslashes($file['relative_path']) ?>","<?= $file['ext'] ?>","<?= $file['size_kb'] ?>","<?= $file['created_str'] ?>","<?= $file['modified_str'] ?>"\n`;
            <?php endforeach; ?>
            const blob = new Blob([csv], {type: 'text/csv'});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'file_export_<?= date('Ymd_His') ?>.csv';
            a.click();
            URL.revokeObjectURL(url);
        }
        
        function exportToJSON() {
            const data = <?= json_encode($results) ?>;
            const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'file_export_<?= date('Ymd_His') ?>.json';
            a.click();
            URL.revokeObjectURL(url);
        }
        
        window.onclick = function(event) {
            const modal = document.getElementById('previewModal');
            if (event.target == modal) closeModal();
        }
        
        document.querySelectorAll('.tree-children').forEach(el => el.classList.add('open'));
    </script>
</body>
</html>

<?php
// Preview endpoint
if (isset($_GET['preview'])) {
    $file = $_GET['preview'];
    if (file_exists($file) && is_readable($file)) {
        $content = file_get_contents($file);
        if (strlen($content) > 100000) {
            $content = substr($content, 0, 100000) . "\n\n... [Bestand afgekapt]";
        }
        echo $content;
    }
    exit;
}

// Download endpoint
if (isset($_GET['download'])) {
    $file = $_GET['download'];
    if (file_exists($file) && is_readable($file)) {
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file) . '"');
        readfile($file);
    }
    exit;
}
?>