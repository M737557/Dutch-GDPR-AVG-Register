<?php
$directory = './';
$toegestaneExtensies = ['txt', 'php', 'html', 'css', 'js', 'jpg', 'png', 'gif'];

$files = array_diff(scandir($directory), ['.', '..']);

foreach ($files as $file) {
    $path = $directory . '/' . $file;
    
    // Alleen tonen als het bestand is (geen map) en extensie in lijst zit
    if (is_file($path)) {
        $extensie = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($extensie, $toegestaneExtensies)) {
            echo $file . '  ' . '<br>' . "\n";
        }
    }
}
?>