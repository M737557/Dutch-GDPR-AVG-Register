<?php
$directory = './';
$toegestaneExtensies = ['txt', 'php', 'html', 'css', 'js', 'log', 'md'];

$files = array_diff(scandir($directory), ['.', '..']);

$bestandInfo = [];

foreach ($files as $file) {
    $path = $directory . '/' . $file;
    
    if (is_file($path)) {
        $extensie = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($extensie, $toegestaneExtensies)) {
            $inhoud = file_get_contents($path);
            $snippet = substr(trim($inhoud), 0, 100); // Eerste 100 karakters
            if (strlen($inhoud) > 100) $snippet .= '...';
            
            $bestandInfo[] = [
                'naam' => $file,
                'extensie' => $extensie,
                'grootte' => filesize($path),
                'datum' => filemtime($path),
                'snippet' => $snippet
            ];
        }
    }
}

// Sorteren op extensie
usort($bestandInfo, function($a, $b) {
    return strcmp($a['extensie'], $b['extensie']);
});

// Tabel met snippet
echo '<style>
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; vertical-align: top; }
    th { background-color: #4CAF50; color: white; }
    .snippet { font-family: monospace; background-color: #f9f9f9; font-size: 12px; max-width: 400px; overflow-x: auto; white-space: pre-wrap; word-break: break-all; }
    .extensie { font-weight: bold; color: #2196F3; }
    tr:hover { background-color: #f5f5f5; }
</style>';

echo '<table>';
echo '<tr><th>Bestand</th><th>Extensie</th><th>Grootte</th><th>Laatste wijziging</th><th>Inhoud (snippet)</th></tr>';

foreach ($bestandInfo as $info) {
    echo '<tr>';
    echo '<td>' . htmlspecialchars($info['naam']) . '</td>';
    echo '<td class="extensie">.' . htmlspecialchars($info['extensie']) . '</td>';
    echo '<td>' . number_format($info['grootte']) . ' bytes</td>';
    echo '<td>' . date('Y-m-d H:i:s', $info['datum']) . '</td>';
    echo '<td class="snippet">' . htmlspecialchars($info['snippet']) . '</td>';
    echo '</tr>';
}

echo '</table>';
echo '<p><strong>Totaal:</strong> ' . count($bestandInfo) . ' bestanden</p>';
?>