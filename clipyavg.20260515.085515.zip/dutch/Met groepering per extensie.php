<?php
$directory = './';
$toegestaneExtensies = ['txt', 'php', 'html', 'css', 'js', 'log'];

$files = array_diff(scandir($directory), ['.', '..']);

// Groeperen per extensie
$groepen = [];
foreach ($files as $file) {
    $path = $directory . '/' . $file;
    if (is_file($path)) {
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($ext, $toegestaneExtensies)) {
            $groepen[$ext][] = $file;
        }
    }
}

// Weergeven per groep
foreach ($groepen as $extensie => $bestanden) {
    echo "<h3>.{$extensie} bestanden (" . count($bestanden) . ")</h3>";
    echo "<ul>";
    foreach ($bestanden as $bestand) {
        echo "<li>" . htmlspecialchars($bestand) . "</li>";
    }
    echo "</ul>";
}
?>