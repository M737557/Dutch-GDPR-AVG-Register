<?php
$directory = './';
$toegestaneExtensies = ['txt', 'php', 'html', 'css', 'js', 'log', 'md'];

$files = array_diff(scandir($directory), ['.', '..']);

$bestandInfo = [];

foreach ($files as $file) {
    $path = $directory . '/' . $file;
    
    if (is_file($path)) {
        $extensie = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($extensie, $toegestaneExtensies)) {
            $volledigeInhoud = file_get_contents($path);
            $snippet = substr(trim($volledigeInhoud), 0, 100);
            if (strlen($volledigeInhoud) > 100) $snippet .= '...';
            
            $bestandInfo[] = [
                'naam' => $file,
                'extensie' => $extensie,
                'grootte' => filesize($path),
                'datum' => filemtime($path),
                'snippet' => $snippet,
                'volledig' => $volledigeInhoud
            ];
        }
    }
}

usort($bestandInfo, function($a, $b) {
    return strcmp($a['extensie'], $b['extensie']);
});
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        details {
            border: 1px solid #ddd;
            margin-bottom: 5px;
            padding: 5px;
        }
        summary {
            cursor: pointer;
            font-weight: bold;
            padding: 5px;
            background-color: #f5f5f5;
        }
        summary:hover {
            background-color: #e0e0e0;
        }
        .extensie { color: #2196F3; margin-left: 10px; }
        .snippet { font-family: monospace; font-size: 12px; color: #666; margin-left: 10px; }
        .volledig { 
            font-family: monospace; 
            font-size: 12px; 
            background-color: #f9f9f9; 
            padding: 10px; 
            margin-top: 10px;
            white-space: pre-wrap;
            overflow-x: auto;
        }
        .info { font-size: 12px; color: #888; margin-left: 10px; }
    </style>
</head>
<body>
    <h2>Bestandsoverzicht met inhoud</h2>
    
    <?php foreach ($bestandInfo as $info): ?>
    <details>
        <summary>
            <strong><?= htmlspecialchars($info['naam']) ?></strong>
            <span class="extensie">.<?= $info['extensie'] ?></span>
            <span class="info">(<?= number_format($info['grootte']) ?> bytes, <?= date('Y-m-d', $info['datum']) ?>)</span>
            <span class="snippet"><?= htmlspecialchars($info['snippet']) ?></span>
        </summary>
        <div class="volledig">
            <?= htmlspecialchars($info['volledig']) ?>
        </div>
    </details>
    <?php endforeach; ?>
    
    <p><strong>Totaal:</strong> <?= count($bestandInfo) ?> bestanden</p>
</body>
</html>