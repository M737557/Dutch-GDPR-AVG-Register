<?php
$directory = './';
$geselecteerdeExt = $_GET['extensie'] ?? '';

// Alle bestanden uitlezen
$files = array_diff(scandir($directory), ['.', '..']);

// Unieke extensies verzamelen voor dropdown
$beschikbareExtensies = [];
foreach ($files as $file) {
    $path = $directory . '/' . $file;
    if (is_file($path)) {
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if ($ext !== '') {
            $beschikbareExtensies[$ext] = $ext;
        }
    }
}
sort($beschikbareExtensies);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Bestandenlijst</title>
</head>
<body>
    <form method="get">
        <select name="extensie">
            <option value="">Alle bestanden</option>
            <?php foreach ($beschikbareExtensies as $ext): ?>
                <option value="<?= $ext ?>" <?= $geselecteerdeExt == $ext ? 'selected' : '' ?>>
                    .<?= $ext ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit">Filter</button>
    </form>

    <ul>
    <?php foreach ($files as $file): ?>
        <?php
        $path = $directory . '/' . $file;
        if (is_file($path)) {
            $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            if (empty($geselecteerdeExt) || $ext === $geselecteerdeExt) {
                echo "<li>" . htmlspecialchars($file) . " (." . $ext . ")</li>";
            }
        }
        ?>
    <?php endforeach; ?>
    </ul>
</body>
</html>