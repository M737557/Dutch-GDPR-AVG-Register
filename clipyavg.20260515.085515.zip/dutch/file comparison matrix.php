<?php
$directory = './';
$files = glob($directory . '*.txt');
$selectedFiles = $_GET['files'] ?? [];
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        .matrix {
            overflow-x: auto;
            margin: 20px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            min-width: 600px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        th {
            background: #4CAF50;
            color: white;
            position: sticky;
            top: 0;
        }
        td {
            background: white;
        }
        .similarity-high {
            background: #4CAF50;
            color: white;
        }
        .similarity-medium {
            background: #FFC107;
        }
        .similarity-low {
            background: #f44336;
            color: white;
        }
        .file-selector {
            background: #f5f5f5;
            padding: 20px;
            border-radius: 10px;
            margin: 20px;
        }
        .file-selector label {
            margin: 0 10px;
            display: inline-block;
        }
        .stats {
            margin: 20px;
            padding: 15px;
            background: #e3f2fd;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div class="file-selector">
        <h3>📊 Selecteer bestanden om te vergelijken</h3>
        <form method="get" id="matrixForm">
            <?php foreach ($files as $file): 
                $name = basename($file);
            ?>
            <label>
                <input type="checkbox" name="files[]" value="<?= $name ?>" 
                       <?= in_array($name, $selectedFiles) ? 'checked' : '' ?>
                       onchange="this.form.submit()">
                <?= $name ?>
            </label>
            <?php endforeach; ?>
        </form>
    </div>
    
    <?php if (count($selectedFiles) >= 2): 
        // Lees alle bestanden in
        $contents = [];
        $wordSets = [];
        $wordFreq = [];
        
        foreach ($selectedFiles as $file) {
            $text = strtolower(file_get_contents($file));
            $words = str_word_count($text, 1);
            $wordSets[$file] = array_count_values($words);
            $contents[$file] = $text;
        }
        
        // Bereken Jaccard gelijkenis
        function jaccardSimilarity($set1, $set2) {
            $intersection = count(array_intersect_key($set1, $set2));
            $union = count($set1) + count($set2) - $intersection;
            return $union > 0 ? $intersection / $union : 0;
        }
        
        // Bereken woord overlap
        $similarities = [];
        foreach ($selectedFiles as $file1) {
            foreach ($selectedFiles as $file2) {
                if ($file1 != $file2) {
                    $similarities[$file1][$file2] = jaccardSimilarity($wordSets[$file1], $wordSets[$file2]);
                } else {
                    $similarities[$file1][$file2] = 1;
                }
            }
        }
    ?>
    
    <div class="matrix">
        <h3>📈 Gelijkenismatrix (Jaccard index)</h3>
        <table>
            <thead>
                <tr>
                    <th>Bestand</th>
                    <?php foreach ($selectedFiles as $file): ?>
                        <th><?= htmlspecialchars($file) ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($selectedFiles as $file1): ?>
                <tr>
                    <th><?= htmlspecialchars($file1) ?></th>
                    <?php foreach ($selectedFiles as $file2): 
                        $sim = $similarities[$file1][$file2];
                        $class = '';
                        if ($sim > 0.7) $class = 'similarity-high';
                        elseif ($sim > 0.4) $class = 'similarity-medium';
                        elseif ($sim < 0.2 && $file1 != $file2) $class = 'similarity-low';
                    ?>
                        <td class="<?= $class ?>">
                            <?= $file1 == $file2 ? '100%' : round($sim * 100) . '%' ?>
                        </td>
                    <?php endforeach; ?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <div class="stats">
        <h3>📊 Gedetailleerde analyse</h3>
        <?php foreach ($selectedFiles as $file): ?>
            <div style="margin-bottom: 20px;">
                <strong>📄 <?= htmlspecialchars($file) ?></strong><br>
                Totaal woorden: <?= array_sum($wordSets[$file]) ?> |
                Unieke woorden: <?= count($wordSets[$file]) ?> |
                Gemiddeld woordlengte: <?= round(strlen($contents[$file]) / str_word_count($contents[$file]), 2) ?> tekens
            </div>
        <?php endforeach; ?>
        
        <h3>🔍 Gemeenschappelijke woorden (top 20)</h3>
        <?php
        $commonWords = [];
        foreach ($wordSets as $file => $words) {
            foreach ($words as $word => $count) {
                $commonWords[$word] = ($commonWords[$word] ?? 0) + 1;
            }
        }
        $commonWords = array_filter($commonWords, function($count) use ($selectedFiles) {
            return $count == count($selectedFiles);
        });
        ?>
        <div style="display: flex; flex-wrap: wrap;">
            <?php foreach (array_slice($commonWords, 0, 20) as $word => $count): ?>
                <span style="background: #e0e0e0; padding: 5px 10px; margin: 5px; border-radius: 15px;">
                    <?= htmlspecialchars($word) ?>
                </span>
            <?php endforeach; ?>
        </div>
    </div>
    
    <?php endif; ?>
</body>
</html>