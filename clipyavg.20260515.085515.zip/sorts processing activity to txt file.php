<?php
// ============================================
// Extract ONLY processing_activity values (without IDs)
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 1);

$data_directory = __DIR__ . '/dutch/';
$output_file = __DIR__ . '/processing_activities_only.txt';

if (!is_dir($data_directory)) {
    die('Data directory not found: ' . htmlspecialchars($data_directory));
}

// Haal alle processing_activities op
$processing_activities = [];

$files = getAllDataFiles($data_directory);

foreach ($files as $file) {
    $entries = parseFileContent($file);
    
    foreach ($entries as $entry) {
        if ($entry['type'] === 'gdpr' && !empty($entry['processing_activity'])) {
            $processing_activities[] = $entry['processing_activity'];
        }
    }
}

// Remove duplicates (optional - comment out if you want to keep duplicates)
$processing_activities = array_unique($processing_activities);
$processing_activities = array_values($processing_activities); // Reindex array

// Write to file - simple list without IDs
$output_content = "";
foreach ($processing_activities as $activity) {
    $output_content .= $activity . "\n";
}

// Write to file
file_put_contents($output_file, $output_content);

// Also output to console
echo "✅ Processing activities exported (without IDs)!\n";
echo "📁 File: " . $output_file . "\n";
echo "📊 Total unique activities found: " . count($processing_activities) . "\n";

// Display preview
echo "\n--- PREVIEW (first 10) ---\n";
for ($i = 0; $i < min(10, count($processing_activities)); $i++) {
    echo ($i+1) . ". " . $processing_activities[$i] . "\n";
}

// ============================================
// Helper Functions
// ============================================

function getAllDataFiles($directory) {
    $files = [];
    if (is_dir($directory)) {
        $all_files = scandir($directory);
        foreach ($all_files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'txt' && $file !== '.' && $file !== '..') {
                $files[] = $directory . $file;
            }
        }
    }
    return $files;
}

function parseFileContent($filepath) {
    $entries = [];
    
    if (!file_exists($filepath)) {
        return $entries;
    }
    
    if (filesize($filepath) > 10485760) { // 10MB max
        return $entries;
    }
    
    $content = @file_get_contents($filepath);
    if ($content === false) {
        return $entries;
    }
    
    $lines = explode("\n", $content);
    
    foreach ($lines as $line) {
        $trimmed = trim($line);
        if (strpos($trimmed, '--') === 0 || $trimmed === '' || strpos($trimmed, 'INSERT INTO') !== false) {
            continue;
        }
        
        if (strpos($trimmed, '(') === 0) {
            $data = parseDataRow($trimmed);
            if ($data && count($data) >= 4) {
                $entry = parseGdprEntry($data);
                if ($entry) {
                    $entries[] = $entry;
                }
            }
        }
    }
    
    return $entries;
}

function parseDataRow($line) {
    // Remove trailing ); or ),
    $line = trim($line);
    $line = rtrim($line, ');');
    $line = rtrim($line, '),');
    
    $values = [];
    $current = '';
    $in_quotes = false;
    $escaped = false;
    $len = strlen($line);
    
    for ($i = 0; $i < $len; $i++) {
        $char = $line[$i];
        
        if ($char === '\\' && !$escaped) {
            $escaped = true;
            $current .= $char;
        } elseif ($char === "'" && !$escaped) {
            $in_quotes = !$in_quotes;
            $current .= $char;
        } elseif ($char === ',' && !$in_quotes && !$escaped) {
            $values[] = trim(trim($current), "'");
            $current = '';
        } else {
            $current .= $char;
            $escaped = false;
        }
    }
    
    if ($current !== '') {
        $values[] = trim(trim($current), "'");
    }
    
    return $values;
}

function parseGdprEntry($data) {
    $gdpr_columns = [
        'id', 'has_processing_agreement_with_third_party', 'we_are_processor', 'processing_activity', 'name_data_controller',
        'contact_data_controller', 'name_joint_data_controller', 'contact_joint_data_controller', 'name_representative',
        'contact_representative', 'name_dpo', 'contact_dpo', 'purpose_of_processing', 'legal_basis',
        'categories_personal_data', 'categories_data_subjects', 'categories_recipients', 'retention_periods',
        'risk_level', 'technical_measures', 'organizational_measures', 'dpia_required', 'is_international_data_transfers',
        'to_country', 'safeguards', 'created_at', 'updated_at', 'review_due_date', 'created_by', 'updated_by',
        'department', 'status', 'legitimate_interest_description', 'dpia_status'
    ];
    
    $entry = ['type' => 'gdpr'];
    
    for ($i = 0; $i < min(count($data), count($gdpr_columns)); $i++) {
        $column_name = $gdpr_columns[$i];
        $entry[$column_name] = $data[$i] ?? '';
    }
    
    return $entry;
}
?>