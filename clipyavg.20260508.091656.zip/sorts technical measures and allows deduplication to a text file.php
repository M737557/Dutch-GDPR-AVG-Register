<?php
// ============================================
// Extract & Save Technical Measures to TXT
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 1);

$data_directory = __DIR__ . '/select/';
$output_file = __DIR__ . '/technical_measures.txt';

if (!is_dir($data_directory)) {
    die('Data directory not found: ' . $data_directory);
}

$technical_measures = [];
$files = getAllDataFiles($data_directory);

foreach ($files as $file) {
    $entries = parseFileContent($file);
    
    foreach ($entries as $entry) {
        if ($entry['type'] === 'gdpr' && !empty($entry['technical_measures'])) {
            $technical_measures[] = trim($entry['technical_measures']);
        }
    }
}

// Remove duplicates
$unique_measures = array_unique($technical_measures);

// Sort alphabetically
sort($unique_measures, SORT_STRING | SORT_FLAG_CASE);

// Save to file
$content = "=== TECHNICAL MEASURES (" . count($unique_measures) . " unique items) ===\n\n";
$content .= implode("\n", $unique_measures);
$content .= "\n\n=== End of file ===\n";

file_put_contents($output_file, $content);

echo "✅ Extracted " . count($technical_measures) . " total measures\n";
echo "✅ Deduplicated to " . count($unique_measures) . " unique measures\n";
echo "✅ Saved to: " . $output_file . "\n";

// ============================================
// Helper Functions
// ============================================

function getAllDataFiles($directory) {
    $files = [];
    if (is_dir($directory)) {
        $all_files = scandir($directory);
        foreach ($all_files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'txt' && $file !== '.' && $file !== '..') {
                $files[] = $directory . $file;
            }
        }
    }
    return $files;
}

function parseFileContent($filepath) {
    $entries = [];
    
    if (!file_exists($filepath) || filesize($filepath) > 10485760) {
        return $entries;
    }
    
    $content = @file_get_contents($filepath);
    if ($content === false) {
        return $entries;
    }
    
    $lines = explode("\n", $content);
    
    foreach ($lines as $line) {
        $trimmed = trim($line);
        if (strpos($trimmed, '--') === 0 || $trimmed === '' || strpos($trimmed, 'INSERT INTO') !== false) {
            continue;
        }
        
        if (strpos($trimmed, '(') === 0) {
            $data = parseDataRow($trimmed);
            if ($data && count($data) >= 33) {
                $entry = parseGdprEntry($data);
                if ($entry) {
                    $entries[] = $entry;
                }
            }
        }
    }
    
    return $entries;
}

function parseDataRow($line) {
    $line = trim($line, ");\n\r\t");
    $line = trim($line, "),");
    
    $values = [];
    $current = '';
    $in_quotes = false;
    $escaped = false;
    
    for ($i = 0; $i < strlen($line); $i++) {
        $char = $line[$i];
        
        if ($char === '\\') {
            $escaped = !$escaped;
            $current .= $char;
        } elseif ($char === "'" && !$escaped) {
            $in_quotes = !$in_quotes;
            $current .= $char;
        } elseif ($char === ',' && !$in_quotes && !$escaped) {
            $values[] = trim($current, "'");
            $current = '';
        } else {
            $current .= $char;
            $escaped = false;
        }
    }
    
    if ($current !== '') {
        $values[] = trim($current, "'");
    }
    
    return $values;
}

function parseGdprEntry($data) {
    $gdpr_columns = [
        'id', 'has_processing_agreement_with_third_party', 'we_are_processor', 'processing_activity', 'name_data_controller',
        'contact_data_controller', 'name_joint_data_controller', 'contact_joint_data_controller', 'name_representative',
        'contact_representative', 'name_dpo', 'contact_dpo', 'purpose_of_processing', 'legal_basis',
        'categories_personal_data', 'categories_data_subjects', 'categories_recipients', 'retention_periods',
        'risk_level', 'technical_measures', 'organizational_measures', 'dpia_required', 'is_international_data_transfers',
        'to_country', 'safeguards', 'created_at', 'updated_at', 'review_due_date', 'created_by', 'updated_by',
        'department', 'status', 'legitimate_interest_description', 'dpia_status'
    ];
    
    $entry = ['type' => 'gdpr'];
    
    for ($i = 0; $i < min(count($data), count($gdpr_columns)); $i++) {
        $column_name = $gdpr_columns[$i];
        $entry[$column_name] = $data[$i] ?? '';
    }
    
    return $entry;
}
?>