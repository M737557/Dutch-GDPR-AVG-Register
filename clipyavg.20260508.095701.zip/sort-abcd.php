<?php
$lines = file('processing_activities_only.txt');
sort($lines);
file_put_contents('sorted.txt', $lines);
?>