<?php
// ============================================
// Extract ALL technical_measures from GDPR txt files
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 1);

$data_directory = __DIR__ . '/select/';

if (!is_dir($data_directory)) {
    die('Data directory not found: ' . htmlspecialchars($data_directory));
}

// Haal alle technical_measures op
$technical_measures = [];

$files = getAllDataFiles($data_directory);

foreach ($files as $file) {
    $entries = parseFileContent($file);
    
    foreach ($entries as $entry) {
        if ($entry['type'] === 'gdpr' && !empty($entry['technical_measures'])) {
            $technical_measures[] = [
                'id' => $entry['id'],
                'processing_activity' => $entry['processing_activity'] ?? 'Onbekend',
                'technical_measures' => $entry['technical_measures'],
                'file' => basename($file),
                'risk_level' => $entry['risk_level'] ?? 'unknown'
            ];
        }
    }
}

// Display the results
displayResults($technical_measures);

// ============================================
// Helper Functions
// ============================================

function getAllDataFiles($directory) {
    $files = [];
    if (is_dir($directory)) {
        $all_files = scandir($directory);
        foreach ($all_files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'txt' && $file !== '.' && $file !== '..') {
                $files[] = $directory . $file;
            }
        }
    }
    return $files;
}

function parseFileContent($filepath) {
    $entries = [];
    
    if (!file_exists($filepath)) {
        return $entries;
    }
    
    if (filesize($filepath) > 10485760) { // 10MB max
        return $entries;
    }
    
    $content = @file_get_contents($filepath);
    if ($content === false) {
        return $entries;
    }
    
    $lines = explode("\n", $content);
    
    foreach ($lines as $line) {
        $trimmed = trim($line);
        if (strpos($trimmed, '--') === 0 || $trimmed === '' || strpos($trimmed, 'INSERT INTO') !== false) {
            continue;
        }
        
        if (strpos($trimmed, '(') === 0) {
            $data = parseDataRow($trimmed);
            if ($data && count($data) >= 33) { // GDPR has 33+ fields
                $entry = parseGdprEntry($data);
                if ($entry) {
                    $entries[] = $entry;
                }
            }
        }
    }
    
    return $entries;
}

function parseDataRow($line) {
    $line = trim($line, ");\n\r\t");
    $line = trim($line, "),");
    
    $values = [];
    $current = '';
    $in_quotes = false;
    $escaped = false;
    
    for ($i = 0; $i < strlen($line); $i++) {
        $char = $line[$i];
        
        if ($char === '\\') {
            $escaped = !$escaped;
            $current .= $char;
        } elseif ($char === "'" && !$escaped) {
            $in_quotes = !$in_quotes;
            $current .= $char;
        } elseif ($char === ',' && !$in_quotes && !$escaped) {
            $values[] = trim($current, "'");
            $current = '';
        } else {
            $current .= $char;
            $escaped = false;
        }
    }
    
    if ($current !== '') {
        $values[] = trim($current, "'");
    }
    
    return $values;
}

function parseGdprEntry($data) {
    $gdpr_columns = [
        'id', 'has_processing_agreement_with_third_party', 'we_are_processor', 'processing_activity', 'name_data_controller',
        'contact_data_controller', 'name_joint_data_controller', 'contact_joint_data_controller', 'name_representative',
        'contact_representative', 'name_dpo', 'contact_dpo', 'purpose_of_processing', 'legal_basis',
        'categories_personal_data', 'categories_data_subjects', 'categories_recipients', 'retention_periods',
        'risk_level', 'technical_measures', 'organizational_measures', 'dpia_required', 'is_international_data_transfers',
        'to_country', 'safeguards', 'created_at', 'updated_at', 'review_due_date', 'created_by', 'updated_by',
        'department', 'status', 'legitimate_interest_description', 'dpia_status'
    ];
    
    $entry = ['type' => 'gdpr'];
    
    // Map all fields to column names
    for ($i = 0; $i < min(count($data), count($gdpr_columns)); $i++) {
        $column_name = $gdpr_columns[$i];
        $entry[$column_name] = $data[$i] ?? '';
    }
    
    return $entry;
}

function displayResults($measures) {
    ?>
    <!DOCTYPE html>
    <html lang="nl">
    <head>
        <meta charset="UTF-8">
        <title>Technical Measures - GDPR Register</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: #f0f2f5;
                padding: 20px;
                line-height: 1.5;
            }
            
            .container {
                max-width: 1400px;
                margin: 0 auto;
                background: white;
                border-radius: 12px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                overflow: hidden;
            }
            
            .header {
                background: linear-gradient(135deg, #0f5c3f, #1a7a55);
                color: white;
                padding: 25px 30px;
            }
            
            .header h1 {
                font-size: 24px;
                margin-bottom: 8px;
            }
            
            .header h1:before {
                content: "🔧 ";
            }
            
            .header p {
                font-size: 14px;
                opacity: 0.9;
            }
            
            .stats {
                background: #e8f4fc;
                padding: 15px 30px;
                border-bottom: 1px solid #cde4f0;
                display: flex;
                gap: 30px;
                flex-wrap: wrap;
            }
            
            .stat {
                display: flex;
                align-items: baseline;
                gap: 8px;
            }
            
            .stat-number {
                font-size: 28px;
                font-weight: bold;
                color: #0f5c3f;
            }
            
            .stat-label {
                font-size: 14px;
                color: #4a6a8a;
            }
            
            .export-btn {
                background: #0f5c3f;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 6px;
                cursor: pointer;
                font-size: 13px;
                transition: background 0.2s;
                margin-left: auto;
            }
            
            .export-btn:hover {
                background: #0a3d2a;
            }
            
            table {
                width: 100%;
                border-collapse: collapse;
            }
            
            th {
                background: #f8f9fc;
                padding: 14px 12px;
                text-align: left;
                font-weight: 600;
                color: #2c3e50;
                border-bottom: 2px solid #e0e4e8;
                position: sticky;
                top: 0;
                background: #f8f9fc;
            }
            
            td {
                padding: 14px 12px;
                border-bottom: 1px solid #e9ecef;
                vertical-align: top;
            }
            
            tr:hover {
                background: #f8f9fc;
            }
            
            .badge {
                display: inline-block;
                padding: 4px 10px;
                border-radius: 20px;
                font-size: 11px;
                font-weight: 600;
            }
            
            .badge-high {
                background: #fee2e2;
                color: #dc2626;
            }
            
            .badge-medium {
                background: #fef3c7;
                color: #d97706;
            }
            
            .badge-low {
                background: #d1fae5;
                color: #059669;
            }
            
            .badge-unknown {
                background: #e5e7eb;
                color: #6b7280;
            }
            
            .measures-cell {
                max-width: 500px;
                word-wrap: break-word;
                white-space: normal;
                line-height: 1.5;
            }
            
            .measures-cell strong {
                color: #0f5c3f;
                display: inline-block;
                margin-top: 5px;
            }
            
            .id-cell {
                font-weight: 600;
                color: #0f5c3f;
                text-align: center;
            }
            
            .activity-cell {
                font-weight: 500;
                max-width: 300px;
            }
            
            .file-cell {
                font-family: monospace;
                font-size: 11px;
                color: #6c757d;
            }
            
            .tag {
                display: inline-block;
                background: #e9ecef;
                padding: 2px 6px;
                border-radius: 4px;
                font-size: 10px;
                font-family: monospace;
                margin: 2px;
            }
            
            .footer {
                background: #f8f9fc;
                padding: 15px 30px;
                text-align: center;
                font-size: 12px;
                color: #6c757d;
                border-top: 1px solid #e0e4e8;
            }
            
            @media (max-width: 768px) {
                body {
                    padding: 10px;
                }
                
                .header h1 {
                    font-size: 18px;
                }
                
                th, td {
                    padding: 10px 8px;
                    font-size: 12px;
                }
                
                .stats {
                    flex-direction: column;
                    gap: 8px;
                }
                
                .export-btn {
                    margin-left: 0;
                    width: fit-content;
                }
            }
            
            @media print {
                body {
                    background: white;
                    padding: 0;
                }
                
                .export-btn, .stats {
                    display: none;
                }
                
                table {
                    font-size: 9pt;
                }
                
                th, td {
                    padding: 6px 4px;
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Technical Measures - GDPR Register</h1>
                <p>Overzicht van alle technische beveiligingsmaatregelen per verwerkingsactiviteit</p>
            </div>
            
            <div class="stats">
                <div class="stat">
                    <span class="stat-number"><?php echo count($measures); ?></span>
                    <span class="stat-label">GDPR Verwerkingen met Technical Measures</span>
                </div>
                <div class="stat">
                    <span class="stat-number">
                        <?php 
                        $high = count(array_filter($measures, function($m) { 
                            return strtolower($m['risk_level']) === 'high'; 
                        }));
                        echo $high;
                        ?>
                    </span>
                    <span class="stat-label">High Risk</span>
                </div>
                <div class="stat">
                    <span class="stat-number">
                        <?php 
                        $medium = count(array_filter($measures, function($m) { 
                            return strtolower($m['risk_level']) === 'medium'; 
                        }));
                        echo $medium;
                        ?>
                    </span>
                    <span class="stat-label">Medium Risk</span>
                </div>
                <div class="stat">
                    <span class="stat-number">
                        <?php 
                        $low = count(array_filter($measures, function($m) { 
                            return strtolower($m['risk_level']) === 'low'; 
                        }));
                        echo $low;
                        ?>
                    </span>
                    <span class="stat-label">Low Risk</span>
                </div>
                <button class="export-btn" onclick="copyToClipboard()">📋 Copy All</button>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th style="width: 60px">ID</th>
                        <th style="width: 250px">Verwerkingsactiviteit</th>
                        <th>Technische Maatregelen</th>
                        <th style="width: 100px">Risico</th>
                        <th style="width: 150px">Bronbestand</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($measures) === 0): ?>
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 40px;">
                                ❌ Geen technical_measures gevonden in de txt bestanden.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($measures as $measure): ?>
                            <tr>
                                <td class="id-cell"><?php echo htmlspecialchars($measure['id']); ?></td>
                                <td class="activity-cell"><?php echo htmlspecialchars($measure['processing_activity']); ?></td>
                                <td class="measures-cell">
                                    <?php 
                                    $measures_text = htmlspecialchars($measure['technical_measures']);
                                    // Extract key technologies for tagging
                                    $keywords = ['encrypt', 'encryption', 'two-factor', '2FA', 'audit', 'logging', 
                                                'access', 'secure', 'firewall', 'SIEM', 'IDS', 'IPS', 'authentication',
                                                'backup', 'encrypted', 'pseudonimisering', 'anonymization', 'consent'];
                                    
                                    // Convert commas to line breaks for better readability
                                    $measures_text = str_replace(', ', ",\n", $measures_text);
                                    echo nl2br($measures_text);
                                    ?>
                                 </td>
                                <td>
                                    <span class="badge badge-<?php echo strtolower($measure['risk_level']); ?>">
                                        <?php echo ucfirst(htmlspecialchars($measure['risk_level'])); ?>
                                    </span>
                                </td>
                                <td class="file-cell"><?php echo htmlspecialchars($measure['file']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <div class="footer">
                <strong>GDPR Register - Technical Measures</strong><br>
                Gegenereerd op <?php echo date('d-m-Y H:i:s'); ?> | Totaal <?php echo count($measures); ?> entries
                <br><br>
                <small>🔐 Technische maatregelen omvatten encryptie, toegangscontrole, logging, authenticatie en meer</small>
            </div>
        </div>
        
        <script>
            function copyToClipboard() {
                let text = "ID\tVerwerkingsactiviteit\tTechnische Maatregelen\tRisico\tBronbestand\n";
                text += "===\t===================\t===================\t=====\t==========\n";
                
                <?php foreach ($measures as $measure): ?>
                text += "<?php echo $measure['id']; ?>\t";
                text += "<?php echo addslashes($measure['processing_activity']); ?>\t";
                text += "<?php echo addslashes($measure['technical_measures']); ?>\t";
                text += "<?php echo $measure['risk_level']; ?>\t";
                text += "<?php echo $measure['file']; ?>\n";
                <?php endforeach; ?>
                
                navigator.clipboard.writeText(text).then(function() {
                    alert("✅ Alle technical_measures zijn gekopieerd naar het klembord!");
                }, function() {
                    alert("❌ Kon niet kopiëren naar klembord.");
                });
            }
        </script>
    </body>
    </html>
    <?php
}
?>